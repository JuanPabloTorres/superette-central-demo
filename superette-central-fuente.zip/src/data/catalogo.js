// ⚠️ DATOS DE EJEMPLO — el catálogo real se sube en minutos desde el panel de Negocio
export const CATEGORIAS = [
  { id: 'viveres', nombre: 'Víveres y Enlatados', icon: 'Package' },
  { id: 'carniceria', nombre: 'Carnicería y Charcutería', icon: 'Beef' },
  { id: 'lacteos', nombre: 'Lácteos y Huevos', icon: 'Milk' },
  { id: 'congelados', nombre: 'Congelados', icon: 'Snowflake' },
  { id: 'panaderia', nombre: 'Panadería', icon: 'Croissant' },
  { id: 'frutas', nombre: 'Frutas y Vegetales', icon: 'Apple' },
  { id: 'granel', nombre: 'A Granel', icon: 'Scale' },
  { id: 'bebidas', nombre: 'Bebidas', icon: 'CupSoda' },
  { id: 'snacks', nombre: 'Snacks y Dulces', icon: 'Cookie' },
  { id: 'hogar', nombre: 'Higiene y Hogar', icon: 'SprayCan' },
  { id: 'licores', nombre: 'Cerveza y Licores', icon: 'Beer' },
]

// unidad: 'und' (por pieza/paquete) | 'lb' (por libra, cantidad puede ser decimal) | 'oz'
export const PRODUCTOS = [
  // Víveres y enlatados
  { id: 'viv-01', nombre: 'Arroz Sello Rojo 5 lb', categoria: 'viveres', unidad: 'und', precio: 6.49, popular: true, fotoId: 5966630 },
  { id: 'viv-02', nombre: 'Habichuelas rosadas enlatadas 15 oz', categoria: 'viveres', unidad: 'und', precio: 1.79, fotoId: 5966431 },
  { id: 'viv-03', nombre: 'Aceite de oliva Goya 24 oz', categoria: 'viveres', unidad: 'und', precio: 8.99, fotoId: 33783 },
  { id: 'viv-04', nombre: 'Salsa de tomate Contadina', categoria: 'viveres', unidad: 'und', precio: 1.49, fotoId: 5966432 },
  { id: 'viv-05', nombre: 'Atún Bumble Bee en agua', categoria: 'viveres', unidad: 'und', precio: 1.99, popular: true, fotoId: 12001951 },
  { id: 'viv-06', nombre: 'Pasta espagueti 16 oz', categoria: 'viveres', unidad: 'und', precio: 1.69, fotoId: 1279330 },
  { id: 'viv-07', nombre: 'Sazón Sofrito Goya', categoria: 'viveres', unidad: 'und', precio: 2.29, fotoId: 5966434 },

  // Carnicería y charcutería
  {
    id: 'car-01', nombre: 'Pechuga de pollo', categoria: 'carniceria', unidad: 'lb', precio: 2.49, popular: true, fotoId: 8251004,
    extras: [{ id: 'sazonada', nombre: 'Sazonada por la casa', precio: 0.5 }],
  },
  { id: 'car-02', nombre: 'Carne molida especial', categoria: 'carniceria', unidad: 'lb', precio: 4.99, popular: true, fotoId: 8444102 },
  { id: 'car-03', nombre: 'Chuletas de cerdo', categoria: 'carniceria', unidad: 'lb', precio: 3.29, fotoId: 12884549 },
  { id: 'car-04', nombre: 'Costillas de cerdo BBQ', categoria: 'carniceria', unidad: 'lb', precio: 3.79, fotoId: 8963030 },
  { id: 'car-05', nombre: 'Jamón de pierna cortado fino', categoria: 'carniceria', unidad: 'lb', precio: 5.49, fotoId: 8963031 },
  { id: 'car-06', nombre: 'Queso de papa (de bola)', categoria: 'carniceria', unidad: 'lb', precio: 4.29, fotoId: 8963032 },
  { id: 'car-07', nombre: 'Longaniza fresca', categoria: 'carniceria', unidad: 'lb', precio: 3.99, fotoId: 8963033 },

  // Lácteos y huevos
  { id: 'lac-01', nombre: 'Leche entera Tres Monjitas 1 gal', categoria: 'lacteos', unidad: 'und', precio: 5.99, popular: true, fotoId: 3735217 },
  { id: 'lac-02', nombre: 'Huevos grado A docena', categoria: 'lacteos', unidad: 'und', precio: 3.49, popular: true, fotoId: 12969328 },
  { id: 'lac-03', nombre: 'Queso de papa amarillo en lasca', categoria: 'lacteos', unidad: 'lb', precio: 4.59, fotoId: 236011 },
  { id: 'lac-04', nombre: 'Mantequilla Tres Monjitas', categoria: 'lacteos', unidad: 'und', precio: 4.29, fotoId: 236012 },
  { id: 'lac-05', nombre: 'Yogur natural 32 oz', categoria: 'lacteos', unidad: 'und', precio: 3.99, fotoId: 236013 },

  // Congelados
  { id: 'con-01', nombre: 'Vegetales mixtos congelados', categoria: 'congelados', unidad: 'und', precio: 2.29, fotoId: 6941012 },
  { id: 'con-02', nombre: 'Pastelillos de carne (12)', categoria: 'congelados', unidad: 'und', precio: 5.49, popular: true, fotoId: 6941013 },
  { id: 'con-03', nombre: 'Papitas fritas congeladas', categoria: 'congelados', unidad: 'und', precio: 3.29, fotoId: 6941014 },
  { id: 'con-04', nombre: 'Helado de vainilla 1.5 qt', categoria: 'congelados', unidad: 'und', precio: 4.99, fotoId: 6941015 },

  // Panadería
  { id: 'pan-01', nombre: 'Pan de agua fresco', categoria: 'panaderia', unidad: 'und', precio: 1.99, popular: true, fotoId: 1775043 },
  { id: 'pan-02', nombre: 'Quesitos (docena)', categoria: 'panaderia', unidad: 'und', precio: 8.99, fotoId: 1775044 },
  { id: 'pan-03', nombre: 'Pan sobao', categoria: 'panaderia', unidad: 'und', precio: 3.49, fotoId: 1775045 },
  { id: 'pan-04', nombre: 'Bizcocho de vainilla porción', categoria: 'panaderia', unidad: 'und', precio: 2.49, fotoId: 1775046 },

  // Frutas y vegetales
  { id: 'fru-01', nombre: 'Guineos verdes', categoria: 'frutas', unidad: 'lb', precio: 0.69, popular: true, fotoId: 2255924 },
  { id: 'fru-02', nombre: 'Aguacate maduro', categoria: 'frutas', unidad: 'und', precio: 1.79, fotoId: 557659 },
  { id: 'fru-03', nombre: 'Tomate de ensalada', categoria: 'frutas', unidad: 'lb', precio: 1.49, fotoId: 533280 },
  { id: 'fru-04', nombre: 'Cebolla amarilla', categoria: 'frutas', unidad: 'lb', precio: 0.99, fotoId: 175415 },
  { id: 'fru-05', nombre: 'Yuca fresca', categoria: 'frutas', unidad: 'lb', precio: 0.89, fotoId: 2255935 },
  { id: 'fru-06', nombre: 'Piña dorada', categoria: 'frutas', unidad: 'und', precio: 2.99, fotoId: 947879 },

  // A granel
  { id: 'gra-01', nombre: 'Arroz a granel', categoria: 'granel', unidad: 'lb', precio: 0.89, popular: true, fotoId: 4198696 },
  { id: 'gra-02', nombre: 'Habichuelas rosadas a granel', categoria: 'granel', unidad: 'lb', precio: 1.29, fotoId: 4198697 },
  { id: 'gra-03', nombre: 'Café molido a granel', categoria: 'granel', unidad: 'lb', precio: 4.49, popular: true, fotoId: 4109743 },
  { id: 'gra-04', nombre: 'Habas blancas a granel', categoria: 'granel', unidad: 'lb', precio: 1.39, fotoId: 4198698 },
  { id: 'gra-05', nombre: 'Especias variadas a granel', categoria: 'granel', unidad: 'oz', precio: 0.45, fotoId: 4198699 },

  // Bebidas
  { id: 'beb-01', nombre: 'Malta India 6-pack', categoria: 'bebidas', unidad: 'und', precio: 5.49, fotoId: 5947018 },
  { id: 'beb-02', nombre: 'Jugo de china 64 oz', categoria: 'bebidas', unidad: 'und', precio: 3.99, popular: true, fotoId: 5947019 },
  { id: 'beb-03', nombre: 'Agua Coamo 24-pack', categoria: 'bebidas', unidad: 'und', precio: 5.99, fotoId: 5947020 },
  { id: 'beb-04', nombre: 'Refresco Coca-Cola 2 L', categoria: 'bebidas', unidad: 'und', precio: 2.79, fotoId: 5947021 },
  { id: 'beb-05', nombre: 'Café con leche listo 32 oz', categoria: 'bebidas', unidad: 'und', precio: 3.29, fotoId: 5947022 },

  // Snacks y dulces
  { id: 'sna-01', nombre: 'Plátano frito (mariquitas)', categoria: 'snacks', unidad: 'und', precio: 2.49, popular: true, fotoId: 5966435 },
  { id: 'sna-02', nombre: 'Chicharrón de cerdo', categoria: 'snacks', unidad: 'und', precio: 3.99, fotoId: 5966436 },
  { id: 'sna-03', nombre: 'Galletas de soda', categoria: 'snacks', unidad: 'und', precio: 1.99, fotoId: 5966437 },
  { id: 'sna-04', nombre: 'Dulce de coco (paquete)', categoria: 'snacks', unidad: 'und', precio: 2.99, fotoId: 5966438 },

  // Higiene y hogar
  { id: 'hog-01', nombre: 'Papel toalla 2 rollos', categoria: 'hogar', unidad: 'und', precio: 3.49, fotoId: 6621452 },
  { id: 'hog-02', nombre: 'Detergente líquido 50 oz', categoria: 'hogar', unidad: 'und', precio: 6.99, fotoId: 6621453 },
  { id: 'hog-03', nombre: 'Papel higiénico 4 rollos', categoria: 'hogar', unidad: 'und', precio: 4.49, popular: true, fotoId: 6621454 },
  { id: 'hog-04', nombre: 'Jabón de baño (paquete de 3)', categoria: 'hogar', unidad: 'und', precio: 3.29, fotoId: 6621455 },

  // Cerveza y licores
  { id: 'lic-01', nombre: 'Medalla Light 12-pack', categoria: 'licores', unidad: 'und', precio: 12.99, popular: true, fotoId: 5946978 },
  { id: 'lic-02', nombre: 'Ron Don Q Cristal 750 ml', categoria: 'licores', unidad: 'und', precio: 11.49, fotoId: 5946979 },
  { id: 'lic-03', nombre: 'Corona Extra 6-pack', categoria: 'licores', unidad: 'und', precio: 8.99, fotoId: 5946980 },
]

export const productosPorCategoria = (catId) => PRODUCTOS.filter((p) => p.categoria === catId)
export const productoPorId = (id) => PRODUCTOS.find((p) => p.id === id)
export const productosPopulares = () => PRODUCTOS.filter((p) => p.popular)
