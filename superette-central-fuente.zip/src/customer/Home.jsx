import { Link } from 'react-router-dom'
import { ShoppingBasket, Tag, Gift, CalendarDays, Clock, Truck, ChevronRight } from 'lucide-react'
import { useDemo, useNow, myActiveOrder, STATUS_SHORT, FLOW } from '../store/DemoStore.jsx'
import { Contenedor, SectionHeader } from '../shell/Layout.jsx'
import { Tarjeta, Button, Badge } from '../ui/index.jsx'
import { IconoCirculo, DivisorOrnamentado } from '../ui/Brand.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'
import { CATEGORIAS, productosPopulares } from '../data/catalogo.js'
import { promoActiva } from '../data/promos.js'
import { EVENTOS } from '../data/events.js'
import { BUSINESS } from '../data/config.js'
import { money, minsUntil } from '../lib/format.js'

export default function Home() {
  const { state } = useDemo()
  useNow(30000)
  const activo = myActiveOrder(state)
  const destacada = promoActiva().find((p) => p.destacada) || promoActiva()[0]

  return (
    <Contenedor>
      {/* Hero */}
      <div className="relative mt-4 overflow-hidden rounded-3xl banda-verde px-6 py-8 text-papel-50 sm:px-10 sm:py-12">
        <div className="pointer-events-none absolute -right-6 -top-10 h-40 w-40 rounded-full bg-white/5" />
        <div className="pointer-events-none absolute -bottom-14 right-10 h-52 w-52 rounded-full bg-white/5" />
        <div className="relative flex flex-col gap-6 sm:flex-row sm:items-center sm:justify-between">
          <div className="max-w-lg">
            <p className="text-sm font-semibold text-verde-100">Hola, {state.account.name.split(' ')[0] === 'Tu' ? 'vecino' : state.account.name.split(' ')[0]}</p>
            <h1 className="mt-1 font-display text-3xl uppercase leading-[1.05] tracking-wide sm:text-4xl">
              Tu compra de siempre, sin hacer fila.
            </h1>
            <p className="mt-3 text-sm text-verde-50/90">
              Pide desde el celular y recógelo en el mostrador o recíbelo en tu casa. Precios claros, sin sorpresas.
            </p>
            <div className="mt-5 flex flex-wrap items-center gap-3">
              <Button as={Link} to="/catalogo" variant="naranja" size="lg">
                <ShoppingBasket size={18} /> Empezar mi compra
              </Button>
              <span className="flex items-center gap-1.5 rounded-full bg-white/15 px-3 py-1.5 text-xs font-bold">
                <span className={`h-2 w-2 rounded-full ${state.settings.acceptingOrders ? 'animate-pulse-ring bg-oliva-300' : 'bg-red-300'}`} />
                {state.settings.acceptingOrders ? 'Abierto ahora' : 'Cerrado'}
              </span>
            </div>
            <div className="mt-4 flex flex-wrap gap-4 text-xs text-verde-50/90">
              <span className="flex items-center gap-1"><Clock size={13} /> Listo en ~{state.settings.prepMinutes} min</span>
              <span className="flex items-center gap-1"><Truck size={13} /> Entrega ${state.settings.deliveryFee.toFixed(2)}</span>
            </div>
          </div>
          <div className="hidden shrink-0 sm:block">
            <FoodArt fotoId={8805171} size="hero" alt="Canasta de compra" className="h-40 w-40 rounded-full border-4 border-white/30" />
          </div>
        </div>
      </div>

      {/* Banda de unidad activa */}
      {activo && <BandaActiva orden={activo} />}

      {/* 4 accesos rápidos */}
      <div className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <AccesoRapido to="/catalogo" icon={ShoppingBasket} label="Ver compra" />
        <AccesoRapido to="/promociones" icon={Tag} label="Promociones" />
        <AccesoRapido to="/cuenta" icon={Gift} label="Mis puntos" />
        <AccesoRapido to="/eventos" icon={CalendarDays} label="Eventos" />
      </div>

      {/* Destacado + recompensas */}
      <div className="mt-8 grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        {destacada && (
          <Tarjeta as={Link} to={`/promo/${destacada.slug}`} hover className="relative flex min-w-0 flex-col overflow-hidden sm:flex-row">
            <FoodArt fotoId={destacada.fotoId} size="card" className="h-40 w-full sm:h-auto sm:w-56" />
            <div className="flex flex-1 flex-col justify-center gap-2 p-5">
              <Badge tone="amber">Promoción destacada</Badge>
              <h3 className="font-display text-xl uppercase tracking-wide text-tinta-900">{destacada.titulo}</h3>
              <p className="text-sm text-tinta-500">{destacada.resumen}</p>
              <span className="mt-1 flex items-center gap-1 text-sm font-bold text-verde-700">Ver detalles <ChevronRight size={16} /></span>
            </div>
          </Tarjeta>
        )}
        <Tarjeta className="flex flex-col justify-center gap-3 p-5">
          <div className="flex items-center gap-3">
            <IconoCirculo icon={Gift} tone="acento" />
            <div>
              <p className="font-display uppercase tracking-wide text-tinta-900">Tus puntos</p>
              <p className="text-sm text-tinta-500">{state.customers.find((c) => c.id === state.account.id)?.puntos ?? 0} pts · faltan {Math.max(0, state.settings.rewardGoalPoints - (state.customers.find((c) => c.id === state.account.id)?.puntos ?? 0))} para ${state.settings.rewardValue} de descuento</p>
            </div>
          </div>
          <div className="h-2 w-full overflow-hidden rounded-full bg-papel-200">
            <div
              className="h-full rounded-full bg-naranja-400"
              style={{ width: `${Math.min(100, ((state.customers.find((c) => c.id === state.account.id)?.puntos ?? 0) / state.settings.rewardGoalPoints) * 100)}%` }}
            />
          </div>
        </Tarjeta>
      </div>

      {/* Categorías */}
      <SectionHeader title="Compra por categoría" action={<Link to="/catalogo" className="text-sm font-bold text-verde-700">Ver todo</Link>} />
      <div className="no-scrollbar -mx-4 flex gap-3 overflow-x-auto px-4 pb-2 sm:mx-0 sm:grid sm:grid-cols-4 sm:px-0 lg:grid-cols-6">
        {CATEGORIAS.map((c) => (
          <Link key={c.id} to={`/catalogo?cat=${c.id}`} className="shrink-0">
            <Tarjeta hover className="flex w-28 flex-col items-center gap-2 px-3 py-4 text-center sm:w-auto">
              <div className="grid h-11 w-11 place-items-center rounded-full bg-verde-50 text-verde-700">
                <ShoppingBasket size={18} />
              </div>
              <span className="text-xs font-semibold text-tinta-700">{c.nombre}</span>
            </Tarjeta>
          </Link>
        ))}
      </div>

      {/* Más pedidos */}
      <SectionHeader title="Lo que más se lleva la gente" />
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-5">
        {productosPopulares().slice(0, 5).map((p) => (
          <Tarjeta key={p.id} hover className="relative flex min-w-0 flex-col overflow-hidden">
            <FoodArt fotoId={p.fotoId} size="tile" className="aspect-square w-full" alt={p.nombre} />
            <div className="flex flex-1 flex-col gap-1 p-3">
              <p className="line-clamp-2 text-sm font-semibold text-tinta-800">{p.nombre}</p>
              <p className="text-sm font-bold text-verde-700">{money(p.precio)}{p.unidad !== 'und' ? ` / ${p.unidad}` : ''}</p>
            </div>
          </Tarjeta>
        ))}
      </div>

      {/* Eventos */}
      <SectionHeader title="Lo que viene" action={<Link to="/eventos" className="text-sm font-bold text-verde-700">Ver todo</Link>} />
      <div className="grid gap-3 sm:grid-cols-3">
        {EVENTOS.slice(0, 3).map((e) => (
          <Tarjeta key={e.id} className="flex min-w-0 gap-3 p-3">
            <FoodArt fotoId={e.fotoId} size="thumb" className="h-16 w-16 shrink-0 rounded-xl" />
            <div className="min-w-0">
              <p className="truncate text-sm font-bold text-tinta-800">{e.titulo}</p>
              <p className="text-xs text-tinta-400">{e.fecha}</p>
            </div>
          </Tarjeta>
        ))}
      </div>

      <DivisorOrnamentado className="my-10" />
      <p className="pb-10 text-center font-serif text-lg italic text-tinta-500">
        “Menos fricción para comprar, más razones para volver.”
      </p>
    </Contenedor>
  )
}

function AccesoRapido({ to, icon: Icon, label }) {
  return (
    <Link to={to}>
      <Tarjeta hover className="flex flex-col items-center gap-2 px-3 py-5 text-center">
        <IconoCirculo icon={Icon} tone="primario" />
        <span className="text-xs font-bold text-tinta-700">{label}</span>
      </Tarjeta>
    </Link>
  )
}

function BandaActiva({ orden }) {
  const chain = FLOW[orden.mode]
  const idx = chain.indexOf(orden.status)
  const restante = minsUntil(orden.eta)
  return (
    <Link to={`/orden/${orden.id}`}>
      <Tarjeta hover className="mt-5 flex items-center gap-4 border-verde-300 bg-verde-50/60 p-4">
        <div className="relative grid h-12 w-12 shrink-0 place-items-center rounded-full bg-verde-600 text-papel-50">
          <span className="absolute inset-0 rounded-full animate-pulse-ring" />
          <ShoppingBasket size={20} />
        </div>
        <div className="min-w-0 flex-1">
          <p className="text-xs font-bold uppercase tracking-wide text-verde-700">{orden.code} · {STATUS_SHORT[orden.status]}</p>
          <p className="truncate text-sm text-tinta-600">{restante > 0 ? `Faltan ~${restante} min` : 'Está por completarse'}</p>
          <div className="mt-2 flex gap-1">
            {chain.map((s, i) => (
              <span key={s} className={`h-1.5 flex-1 rounded-full ${i <= idx ? 'bg-verde-600' : 'bg-papel-300'}`} />
            ))}
          </div>
        </div>
        <ChevronRight size={18} className="shrink-0 text-verde-600" />
      </Tarjeta>
    </Link>
  )
}
