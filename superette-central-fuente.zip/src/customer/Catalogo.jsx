import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Search, Plus, Minus, ShoppingBasket, Flame } from 'lucide-react'
import { CATEGORIAS, PRODUCTOS } from '../data/catalogo.js'
import { useDemo } from '../store/DemoStore.jsx'
import { unitPrice } from '../store/pricing.js'
import { Contenedor, PageHeader } from '../shell/Layout.jsx'
import { Tarjeta, Chip, Sheet, SheetHeader, Button, Checkbox, EmptyState } from '../ui/index.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'
import { money } from '../lib/format.js'

export default function Catalogo() {
  const { state, addToCart, toast } = useDemo()
  const [params, setParams] = useSearchParams()
  const [q, setQ] = useState('')
  const [soloPopulares, setSoloPopulares] = useState(false)
  const [activo, setActivo] = useState(null)
  const catActiva = params.get('cat') || 'todas'

  const disponibles = useMemo(
    () => PRODUCTOS.filter((p) => state.availability[p.id] !== false),
    [state.availability]
  )

  const filtrados = useMemo(() => {
    let list = disponibles
    if (catActiva !== 'todas') list = list.filter((p) => p.categoria === catActiva)
    if (soloPopulares) list = list.filter((p) => p.popular)
    if (q.trim()) list = list.filter((p) => p.nombre.toLowerCase().includes(q.trim().toLowerCase()))
    return list
  }, [disponibles, catActiva, soloPopulares, q])

  const grupos = useMemo(() => {
    const cats = catActiva === 'todas' ? CATEGORIAS : CATEGORIAS.filter((c) => c.id === catActiva)
    return cats
      .map((c) => ({ ...c, productos: filtrados.filter((p) => p.categoria === c.id) }))
      .filter((g) => g.productos.length > 0)
  }, [filtrados, catActiva])

  return (
    <Contenedor>
      <PageHeader title="Tu compra" sub="Busca por producto o filtra por pasillo — precios por unidad o por libra, siempre claros." />

      <div className="flex items-center gap-2 rounded-2xl border border-papel-300 bg-white px-4 py-3">
        <Search size={18} className="text-tinta-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Buscar arroz, pollo, café…"
          className="w-full bg-transparent text-sm outline-none placeholder:text-tinta-300"
        />
      </div>

      <div className="sticky top-[114px] z-30 -mx-4 mt-4 flex gap-2 overflow-x-auto papel px-4 py-3 no-scrollbar sm:mx-0 sm:px-0">
        <Chip active={catActiva === 'todas'} onClick={() => setParams({})}>Todo</Chip>
        {CATEGORIAS.map((c) => (
          <Chip key={c.id} active={catActiva === c.id} onClick={() => setParams({ cat: c.id })}>{c.nombre}</Chip>
        ))}
        <Chip active={soloPopulares} onClick={() => setSoloPopulares((v) => !v)}>
          <Flame size={14} className="mr-1 inline" /> Más populares
        </Chip>
      </div>

      {grupos.length === 0 && (
        <EmptyState icon={Search} title="No encontramos productos con ese filtro." action={<Button variant="soft" onClick={() => { setQ(''); setSoloPopulares(false); setParams({}) }}>Quitar filtros</Button>} />
      )}

      {grupos.map((g) => (
        <div key={g.id} className="mt-8">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="font-display text-lg uppercase tracking-wide text-tinta-900">{g.nombre}</h2>
            <span className="text-xs font-semibold text-tinta-400">{g.productos.length} productos</span>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-4">
            {g.productos.map((p) => (
              <Tarjeta key={p.id} hover className="flex min-w-0 flex-col overflow-hidden">
                <button onClick={() => setActivo(p)} className="text-left">
                  <FoodArt fotoId={p.fotoId} size="tile" className="aspect-square w-full" alt={p.nombre} />
                  <div className="flex flex-col gap-1 p-3">
                    <p className="line-clamp-2 min-h-[2.5em] text-sm font-semibold text-tinta-800">{p.nombre}</p>
                    <p className="text-sm font-bold text-verde-700">
                      {money(p.precio)}{p.unidad !== 'und' ? ` / ${p.unidad}` : ''}
                    </p>
                  </div>
                </button>
                <div className="px-3 pb-3">
                  <Button variant="primary" size="sm" className="w-full" onClick={() => setActivo(p)}>
                    <Plus size={15} /> Agregar
                  </Button>
                </div>
              </Tarjeta>
            ))}
          </div>
        </div>
      ))}

      <ConfiguradorProducto
        producto={activo}
        onClose={() => setActivo(null)}
        onAgregar={(cantidad, extras) => {
          addToCart(activo.id, cantidad, extras)
          toast(`${activo.nombre} agregado a tu compra`, 'success')
          setActivo(null)
        }}
      />
    </Contenedor>
  )
}

function ConfiguradorProducto({ producto, onClose, onAgregar }) {
  const paso = producto?.unidad === 'lb' ? 0.5 : 1
  const [cantidad, setCantidad] = useState(paso)
  const [extras, setExtras] = useState([])

  useEffect(() => {
    if (producto) { setCantidad(producto.unidad === 'lb' ? 0.5 : 1); setExtras([]) }
  }, [producto?.id])

  const abrir = !!producto
  const unidadLabel = producto?.unidad === 'lb' ? 'lb' : producto?.unidad === 'oz' ? 'oz' : 'und'
  const precio = producto ? unitPrice(producto.id, extras, {}) : 0

  const reset = () => { setCantidad(paso); setExtras([]) }

  return (
    <Sheet open={abrir} onClose={() => { reset(); onClose() }} labelledBy="config-titulo">
      {producto && (
        <>
          <SheetHeader id="config-titulo" title={producto.nombre} subtitle={`${money(producto.precio)} por ${unidadLabel}`} onClose={() => { reset(); onClose() }} />
          <div className="space-y-5 px-5 py-5">
            <FoodArt fotoId={producto.fotoId} size="card" className="h-40 w-full rounded-2xl" alt={producto.nombre} />

            {producto.extras?.length > 0 && (
              <div>
                <p className="mb-2 text-sm font-semibold text-tinta-700">Extras</p>
                <div className="space-y-2">
                  {producto.extras.map((e) => (
                    <Checkbox
                      key={e.id}
                      label={e.nombre}
                      right={`+${money(e.precio)}`}
                      checked={extras.includes(e.id)}
                      onChange={() => setExtras((cur) => (cur.includes(e.id) ? cur.filter((x) => x !== e.id) : [...cur, e.id]))}
                    />
                  ))}
                </div>
              </div>
            )}

            <div>
              <p className="mb-2 text-sm font-semibold text-tinta-700">Cantidad ({unidadLabel})</p>
              <div className="flex items-center gap-4">
                <button
                  aria-label="Reducir cantidad"
                  onClick={() => setCantidad((c) => Math.max(paso, +(c - paso).toFixed(2)))}
                  className="grid h-10 w-10 place-items-center rounded-full border border-papel-300 text-tinta-600 hover:border-verde-400"
                >
                  <Minus size={16} />
                </button>
                <span className="w-14 text-center font-display text-xl text-tinta-900">{cantidad}</span>
                <button
                  aria-label="Aumentar cantidad"
                  onClick={() => setCantidad((c) => +(c + paso).toFixed(2))}
                  className="grid h-10 w-10 place-items-center rounded-full border border-papel-300 text-tinta-600 hover:border-verde-400"
                >
                  <Plus size={16} />
                </button>
              </div>
            </div>
          </div>
          <div className="border-t border-papel-200 px-5 py-4">
            <Button variant="primary" size="lg" className="w-full justify-between px-6" onClick={() => { onAgregar(cantidad, extras); reset() }}>
              <span className="flex items-center gap-2"><ShoppingBasket size={18} /> Agregar</span>
              <span>{money(precio * cantidad)}</span>
            </Button>
          </div>
        </>
      )}
    </Sheet>
  )
}
