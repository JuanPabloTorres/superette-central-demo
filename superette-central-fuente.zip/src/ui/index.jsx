import { useEffect, useRef } from 'react'
import { X } from 'lucide-react'

export function cx(...a) {
  return a.filter(Boolean).join(' ')
}

export function Button({ as: Tag = 'button', variant = 'primary', size = 'md', className = '', children, ...rest }) {
  const base =
    'inline-flex items-center justify-center gap-2 font-bold transition-all duration-150 active:scale-[.975] disabled:opacity-40 disabled:pointer-events-none select-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-naranja-400'
  const sizes = {
    sm: 'h-9 px-4 text-[13px] rounded-full',
    md: 'h-11 px-5 text-sm rounded-full',
    lg: 'h-13 px-6 text-[15px] rounded-full',
    icon: 'h-10 w-10 rounded-full',
  }
  const variants = {
    primary: 'bg-verde-600 text-papel-50 shadow-lg shadow-verde-900/25 hover:bg-verde-700',
    naranja: 'bg-naranja-500 text-papel-50 shadow-lg shadow-naranja-600/25 hover:bg-naranja-600',
    oliva: 'bg-oliva-500 text-papel-50 shadow-lg shadow-oliva-700/25 hover:bg-oliva-600',
    dark: 'bg-tinta-800 text-papel-100 hover:bg-tinta-700',
    ghost: 'text-tinta-700 hover:bg-papel-200',
    outline: 'border-[1.5px] border-verde-500 bg-transparent text-verde-600 hover:bg-verde-50',
    papel: 'border border-papel-300 bg-papel-50 text-tinta-700 hover:border-naranja-400 hover:text-verde-600',
    soft: 'bg-papel-200 text-tinta-700 hover:bg-papel-300',
    danger: 'bg-red-50 text-red-600 hover:bg-red-100',
  }
  return (
    <Tag className={cx(base, sizes[size], variants[variant], className)} {...rest}>
      {children}
    </Tag>
  )
}

export function Badge({ tone = 'neutral', className = '', children }) {
  const tones = {
    neutral: 'bg-papel-200 text-tinta-700',
    red: 'bg-red-100 text-red-700',
    amber: 'bg-naranja-100 text-naranja-600',
    green: 'bg-oliva-100 text-oliva-700',
    dark: 'bg-tinta-800 text-papel-100',
    cream: 'bg-papel-100 text-tinta-600 border border-papel-300',
    outline: 'border border-papel-300 text-tinta-600',
  }
  return <span className={cx('inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-bold uppercase tracking-wide', tones[tone], className)}>{children}</span>
}

export function Cinta({ tone = 'naranja', className = '', children }) {
  const tones = { naranja: 'bg-naranja-500 text-papel-50', verde: 'bg-verde-600 text-papel-50', dark: 'bg-tinta-900/80 text-papel-50' }
  return <span className={cx('absolute left-3 top-3 z-10 rounded-full px-3 py-1 text-[11px] font-bold uppercase tracking-wide shadow', tones[tone], className)}>{children}</span>
}

export function Tarjeta({ as: Tag = 'div', hover = false, className = '', children, ...rest }) {
  return (
    <Tag
      className={cx(
        'rounded-2xl border border-papel-300 bg-white shadow-sm shadow-tinta-900/5',
        hover && 'transition-all duration-150 hover:-translate-y-0.5 hover:border-naranja-300 hover:shadow-md',
        className
      )}
      {...rest}
    >
      {children}
    </Tag>
  )
}

export function useAutoFocus(open) {
  const ref = useRef(null)
  useEffect(() => {
    if (open && ref.current) {
      const t = setTimeout(() => ref.current?.focus(), 30)
      return () => clearTimeout(t)
    }
  }, [open])
  return ref
}

export function SheetHeader({ title, subtitle, onClose, id }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-papel-200 px-5 py-4">
      <div>
        <h3 id={id} className="font-display text-lg uppercase tracking-wide text-tinta-900">{title}</h3>
        {subtitle && <p className="mt-0.5 text-sm text-tinta-500">{subtitle}</p>}
      </div>
      <button aria-label="Cerrar" onClick={onClose} className="grid h-9 w-9 shrink-0 place-items-center rounded-full text-tinta-500 hover:bg-papel-200">
        <X size={18} />
      </button>
    </div>
  )
}

export function Sheet({ open, onClose, labelledBy, children }) {
  const focusRef = useAutoFocus(open)
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center sm:items-center" role="dialog" aria-modal="true" aria-labelledby={labelledBy}>
      <div className="absolute inset-0 bg-tinta-950/50 animate-fade" onClick={onClose} />
      <div
        ref={focusRef}
        tabIndex={-1}
        className="relative max-h-[88vh] w-full overflow-y-auto rounded-t-3xl bg-white shadow-2xl animate-sheet sm:max-w-lg sm:rounded-3xl sm:animate-pop"
      >
        {children}
      </div>
    </div>
  )
}

export function Modal({ open, onClose, size = 'md', children }) {
  const focusRef = useAutoFocus(open)
  if (!open) return null
  const sizes = { sm: 'sm:max-w-sm', md: 'sm:max-w-md', lg: 'sm:max-w-2xl' }
  return (
    <div className="fixed inset-0 z-[80] flex items-end justify-center p-0 sm:items-center sm:p-4" role="dialog" aria-modal="true">
      <div className="absolute inset-0 bg-tinta-950/55 animate-fade" onClick={onClose} />
      <div ref={focusRef} tabIndex={-1} className={cx('relative max-h-[90vh] w-full overflow-y-auto rounded-t-3xl bg-white shadow-2xl animate-sheet sm:rounded-3xl sm:animate-pop', sizes[size])}>
        {children}
      </div>
    </div>
  )
}

export function Segmented({ value, onChange, options }) {
  return (
    <div className="inline-flex rounded-full bg-papel-200 p-1">
      {options.map((opt) => (
        <button
          key={opt.value}
          onClick={() => onChange(opt.value)}
          className={cx(
            'rounded-full px-4 py-1.5 text-sm font-bold transition-all',
            value === opt.value ? 'bg-white text-verde-700 shadow' : 'text-tinta-500 hover:text-tinta-700'
          )}
        >
          {opt.label}
        </button>
      ))}
    </div>
  )
}

export function Chip({ active, onClick, className = '', children }) {
  return (
    <button
      onClick={onClick}
      className={cx(
        'shrink-0 rounded-full border px-4 py-2 text-sm font-semibold transition-colors',
        active ? 'border-verde-600 bg-verde-600 text-papel-50' : 'border-papel-300 bg-white text-tinta-600 hover:border-verde-400',
        className
      )}
    >
      {children}
    </button>
  )
}

export function Switch({ checked, onChange, label }) {
  return (
    <label className="flex cursor-pointer items-center justify-between gap-3">
      {label && <span className="text-sm font-medium text-tinta-700">{label}</span>}
      <button
        type="button"
        role="switch"
        aria-checked={checked}
        onClick={() => onChange(!checked)}
        className={cx('relative h-7 w-12 shrink-0 rounded-full transition-colors', checked ? 'bg-verde-600' : 'bg-papel-300')}
      >
        <span className={cx('absolute top-1 h-5 w-5 rounded-full bg-white shadow transition-transform', checked ? 'translate-x-6' : 'translate-x-1')} />
      </button>
    </label>
  )
}

export function Field({ label, hint, required, className = '', children }) {
  return (
    <label className={cx('block', className)}>
      {label && (
        <span className="mb-1.5 block text-sm font-semibold text-tinta-700">
          {label} {required && <span className="text-naranja-500">*</span>}
        </span>
      )}
      {children}
      {hint && <span className="mt-1 block text-xs text-tinta-400">{hint}</span>}
    </label>
  )
}

const inputBase = 'w-full rounded-xl border border-papel-300 bg-white px-3.5 py-2.5 text-sm text-tinta-800 outline-none transition-colors focus:border-verde-500 focus:ring-2 focus:ring-verde-100 placeholder:text-tinta-300'

export function Input(props) {
  return <input className={cx(inputBase, props.className)} {...props} />
}

export function Textarea(props) {
  return <textarea className={cx(inputBase, 'min-h-24 resize-none', props.className)} {...props} />
}

export function Select({ className, children, ...rest }) {
  return (
    <select className={cx(inputBase, 'pr-8', className)} {...rest}>
      {children}
    </select>
  )
}

export function Radio({ label, right, className = '', ...rest }) {
  return (
    <label className={cx('flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-papel-300 px-3.5 py-3 transition-colors has-[:checked]:border-verde-500 has-[:checked]:bg-verde-50', className)}>
      <span className="flex items-center gap-2.5">
        <input type="radio" className="h-4 w-4 accent-verde-600" {...rest} />
        <span className="text-sm font-medium text-tinta-800">{label}</span>
      </span>
      {right && <span className="text-sm font-semibold text-tinta-500">{right}</span>}
    </label>
  )
}

export function Checkbox({ label, right, className = '', ...rest }) {
  return (
    <label className={cx('flex cursor-pointer items-center justify-between gap-3 rounded-xl border border-papel-300 px-3.5 py-3 transition-colors has-[:checked]:border-verde-500 has-[:checked]:bg-verde-50', className)}>
      <span className="flex items-center gap-2.5">
        <input type="checkbox" className="h-4 w-4 rounded accent-verde-600" {...rest} />
        <span className="text-sm font-medium text-tinta-800">{label}</span>
      </span>
      {right && <span className="text-sm font-semibold text-tinta-500">{right}</span>}
    </label>
  )
}

export function EmptyState({ icon: Icon, title, action }) {
  return (
    <div className="flex flex-col items-center gap-3 rounded-2xl border border-dashed border-papel-300 px-6 py-12 text-center">
      {Icon && (
        <div className="grid h-12 w-12 place-items-center rounded-full bg-papel-200 text-tinta-400">
          <Icon size={22} />
        </div>
      )}
      <p className="text-sm font-medium text-tinta-500">{title}</p>
      {action}
    </div>
  )
}

export function DemoDataNote({ className = '' }) {
  return <p className={cx('mt-2 text-center text-[11px] text-tinta-400', className)}>Datos de ejemplo para esta demostración.</p>
}
