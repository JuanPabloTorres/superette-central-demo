import { useEffect, useState } from 'react'
import { Routes, Route, Navigate, Link, useLocation, useNavigate } from 'react-router-dom'
import { AlertTriangle, RefreshCcw, HelpCircle, ShoppingBasket, Home, Grid2x2, Bell, User, Store } from 'lucide-react'
import { useDemo, useCartCount } from '../store/DemoStore.jsx'
import { Contenedor } from './Layout.jsx'
import { Segmented, Badge, cx } from '../ui/index.jsx'
import { Wordmark } from '../ui/Brand.jsx'
import { Toaster } from './Toaster.jsx'
import { Guide } from './Guide.jsx'
import { BUSINESS } from '../data/config.js'

import Home_ from '../customer/Home.jsx'
import Catalogo from '../customer/Catalogo.jsx'
import Promociones from '../customer/Promociones.jsx'
import PromoDetalle from '../customer/PromoDetalle.jsx'
import Carrito from '../customer/Carrito.jsx'
import Checkout from '../customer/Checkout.jsx'
import OrdenSeguimiento from '../customer/OrdenSeguimiento.jsx'
import MisOrdenes from '../customer/MisOrdenes.jsx'
import Alertas from '../customer/Alertas.jsx'
import Cuenta from '../customer/Cuenta.jsx'
import Eventos from '../customer/Eventos.jsx'

import NegocioResumen from '../negocio/Resumen.jsx'
import NegocioEmpaque from '../negocio/Empaque.jsx'
import NegocioCatalogo from '../negocio/CatalogoAdmin.jsx'
import NegocioPromociones from '../negocio/PromocionesAdmin.jsx'
import NegocioClientes from '../negocio/Clientes.jsx'
import NegocioCanales from '../negocio/Canales.jsx'
import NegocioConfig from '../negocio/Config.jsx'

export function Shell() {
  const { state, reset } = useDemo()
  const location = useLocation()
  const navigate = useNavigate()
  const [guideOpen, setGuideOpen] = useState(false)
  const cartCount = useCartCount()
  const modoNegocio = location.pathname.startsWith('/negocio')

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' })
  }, [location.pathname])

  return (
    <div className="min-h-screen papel pb-16 lg:pb-0">
      {/* Barra de demo */}
      <div className="sticky top-0 z-50 flex h-11 items-center justify-between gap-3 bg-tinta-900 px-3 text-papel-100 sm:px-5">
        <div className="flex min-w-0 items-center gap-2 text-[11px] sm:text-xs">
          <AlertTriangle size={14} className="shrink-0 text-naranja-300" />
          <span className="truncate">Demostración — datos simulados</span>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <button onClick={() => setGuideOpen(true)} className="flex items-center gap-1 text-[11px] font-semibold text-papel-200 hover:text-white sm:text-xs">
            <HelpCircle size={14} /> <span className="hidden sm:inline">Guía</span>
          </button>
          <button onClick={reset} className="flex items-center gap-1 text-[11px] font-semibold text-papel-200 hover:text-white sm:text-xs">
            <RefreshCcw size={14} /> <span className="hidden sm:inline">Reiniciar</span>
          </button>
          <Segmented
            value={modoNegocio ? 'negocio' : 'cliente'}
            onChange={(v) => navigate(v === 'negocio' ? '/negocio' : '/')}
            options={[{ value: 'cliente', label: 'Cliente' }, { value: 'negocio', label: 'Negocio' }]}
          />
        </div>
      </div>

      {/* Cabecera del portal */}
      <div className="sticky top-11 z-40 border-b border-papel-300 bg-white/95 backdrop-blur">
        <Contenedor className="flex h-[70px] items-center justify-between gap-4">
          <Link to={modoNegocio ? '/negocio' : '/'} className="flex items-center gap-2">
            <Wordmark />
          </Link>
          {!modoNegocio && (
            <nav className="hidden items-center gap-5 text-sm font-semibold text-tinta-600 lg:flex">
              <Link to="/" className={cx('hover:text-verde-600', location.pathname === '/' && 'text-verde-700')}>Inicio</Link>
              <Link to="/catalogo" className={cx('hover:text-verde-600', location.pathname === '/catalogo' && 'text-verde-700')}>Compra</Link>
              <Link to="/promociones" className={cx('hover:text-verde-600', location.pathname.startsWith('/promo') && 'text-verde-700')}>Promociones</Link>
              <Link to="/eventos" className={cx('hover:text-verde-600', location.pathname === '/eventos' && 'text-verde-700')}>Eventos</Link>
            </nav>
          )}
          {modoNegocio && (
            <nav className="hidden items-center gap-5 text-sm font-semibold text-tinta-600 lg:flex">
              <Link to="/negocio" className={cx('hover:text-verde-600', location.pathname === '/negocio' && 'text-verde-700')}>Resumen</Link>
              <Link to="/negocio/empaque" className={cx('hover:text-verde-600', location.pathname === '/negocio/empaque' && 'text-verde-700')}>Operación</Link>
              <Link to="/negocio/catalogo" className={cx('hover:text-verde-600', location.pathname === '/negocio/catalogo' && 'text-verde-700')}>Catálogo</Link>
              <Link to="/negocio/promociones" className={cx('hover:text-verde-600', location.pathname === '/negocio/promociones' && 'text-verde-700')}>Promociones</Link>
              <Link to="/negocio/clientes" className={cx('hover:text-verde-600', location.pathname === '/negocio/clientes' && 'text-verde-700')}>Clientes</Link>
              <Link to="/negocio/canales" className={cx('hover:text-verde-600', location.pathname === '/negocio/canales' && 'text-verde-700')}>Canales</Link>
            </nav>
          )}
          <div className="flex items-center gap-3">
            {!modoNegocio ? (
              <Link to="/carrito" aria-label="Carrito" className="relative grid h-10 w-10 place-items-center rounded-full text-tinta-700 hover:bg-papel-200">
                <ShoppingBasket size={20} />
                {cartCount > 0 && (
                  <Badge tone="amber" className="absolute -right-1 -top-1 h-5 min-w-5 justify-center px-1">{cartCount}</Badge>
                )}
              </Link>
            ) : (
              <Link to="/negocio/config" aria-label="Configuración" className="grid h-10 w-10 place-items-center rounded-full text-tinta-700 hover:bg-papel-200">
                <Store size={20} />
              </Link>
            )}
          </div>
        </Contenedor>
      </div>

      <main>
        <Routes>
          <Route path="/" element={<Home_ />} />
          <Route path="/catalogo" element={<Catalogo />} />
          <Route path="/promociones" element={<Promociones />} />
          <Route path="/promo/:slug" element={<PromoDetalle />} />
          <Route path="/carrito" element={<Carrito />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/orden/:id" element={<OrdenSeguimiento />} />
          <Route path="/mis-ordenes" element={<MisOrdenes />} />
          <Route path="/alertas" element={<Alertas />} />
          <Route path="/cuenta" element={<Cuenta />} />
          <Route path="/eventos" element={<Eventos />} />

          <Route path="/negocio" element={<NegocioResumen />} />
          <Route path="/negocio/empaque" element={<NegocioEmpaque />} />
          <Route path="/negocio/catalogo" element={<NegocioCatalogo />} />
          <Route path="/negocio/promociones" element={<NegocioPromociones />} />
          <Route path="/negocio/clientes" element={<NegocioClientes />} />
          <Route path="/negocio/canales" element={<NegocioCanales />} />
          <Route path="/negocio/config" element={<NegocioConfig />} />

          {/* Redirecciones de rutas antiguas */}
          <Route path="/menu" element={<Navigate to="/catalogo" replace />} />
          <Route path="/negocio/menu" element={<Navigate to="/negocio/catalogo" replace />} />
          <Route path="/servicios" element={<Navigate to="/catalogo" replace />} />
          <Route path="/negocio/cocina" element={<Navigate to="/negocio/empaque" replace />} />
          <Route path="/negocio/agenda" element={<Navigate to="/negocio/empaque" replace />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <footer className="mt-16 border-t border-papel-300 bg-white py-10">
        <Contenedor className="flex flex-col items-center gap-2 text-center">
          <Wordmark size="sm" />
          <p className="font-serif text-base italic text-tinta-500">Tu compra de siempre, con menos filas y más tiempo para ti.</p>
          <p className="text-xs text-tinta-400">{BUSINESS.town} · {BUSINESS.phone}</p>
        </Contenedor>
      </footer>

      {!modoNegocio && (
        <nav className="fixed inset-x-0 bottom-0 z-50 flex h-16 items-stretch border-t border-papel-300 bg-white lg:hidden">
          <BottomLink to="/" icon={Home} label="Inicio" active={location.pathname === '/'} />
          <BottomLink to="/catalogo" icon={Grid2x2} label="Compra" active={location.pathname === '/catalogo'} />
          <BottomLink to="/carrito" icon={ShoppingBasket} label="Carrito" active={location.pathname === '/carrito'} badge={cartCount} />
          <BottomLink to="/alertas" icon={Bell} label="Alertas" active={location.pathname === '/alertas'} badge={state.notifications.filter((n) => !n.read).length} />
          <BottomLink to="/cuenta" icon={User} label="Cuenta" active={location.pathname === '/cuenta'} />
        </nav>
      )}

      <Toaster />
      <Guide open={guideOpen} onClose={() => setGuideOpen(false)} />
    </div>
  )
}

function BottomLink({ to, icon: Icon, label, active, badge }) {
  return (
    <Link to={to} className={cx('relative flex flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold', active ? 'text-verde-700' : 'text-tinta-400')}>
      <Icon size={20} />
      {label}
      {badge > 0 && <Badge tone="amber" className="absolute right-4 top-1 h-4 min-w-4 justify-center px-1 text-[9px]">{badge}</Badge>}
    </Link>
  )
}
