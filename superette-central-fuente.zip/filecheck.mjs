import { chromium } from 'playwright'
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })
const page = await browser.newPage()
const errors = []
page.on('pageerror', (e) => errors.push('PAGEERROR: ' + e.message))
await page.goto('file:///home/claude/superette-demo/dist/index.html')
await page.waitForTimeout(1200)
const rootLen = await page.evaluate(() => document.getElementById('root')?.innerHTML?.length || 0)
console.log('root innerHTML length:', rootLen)
console.log('PAGEERRORS:', JSON.stringify(errors))
await page.screenshot({ path: '/home/claude/shot-file-protocol.png' })
await browser.close()
