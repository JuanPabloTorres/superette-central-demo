import { chromium } from 'playwright'
const B = 'http://127.0.0.1:4176/'
const RUTAS = [
  '#/', '#/catalogo', '#/promociones', '#/promo/viernes-de-pechuga', '#/carrito',
  '#/mis-ordenes', '#/alertas', '#/cuenta', '#/eventos',
  '#/negocio', '#/negocio/empaque', '#/negocio/catalogo', '#/negocio/promociones',
  '#/negocio/clientes', '#/negocio/canales', '#/negocio/config',
]
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })
let errors = []
for (const w of [360, 390, 414, 1280]) {
  const page = await browser.newPage({ viewport: { width: w, height: 800 } })
  page.on('pageerror', (err) => errors.push(`[${w}px ${page.url()}] PAGEERROR: ${err.message}`))
  for (const r of RUTAS) {
    await page.goto(B + r)
    await page.waitForTimeout(500)
    const info = await page.evaluate(() => ({ vw: document.documentElement.clientWidth, sw: document.documentElement.scrollWidth }))
    if (info.vw !== info.sw) console.log(w, r, `DESBORDA ${info.sw} vs ${info.vw}`)
  }
  await page.close()
}
await browser.close()
console.log(errors.length ? errors.join('\n') : 'Sin overflow. Sin errores de página en ninguna ruta/ancho.')
