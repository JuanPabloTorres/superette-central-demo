// ⚠️ DATOS DE EJEMPLO — sustituye por la información real del negocio antes de presentar
export const BUSINESS = {
  name: 'Superette Central',
  tagline: 'Tu compra de siempre, sin hacer fila.',
  town: 'Villalba, Puerto Rico',
  address: 'Calle Muñoz Rivera esq. Barbosa, Villalba, PR 00766',
  phone: '(787) 847-0000',
  whatsapp: '(787) 847-0000',
  instagram: '@superette.central',
  facebook: 'Superette Central',
  hours: [
    { day: 'Lunes', open: '7:00 am', close: '9:00 pm' },
    { day: 'Martes', open: '7:00 am', close: '9:00 pm' },
    { day: 'Miércoles', open: '7:00 am', close: '9:00 pm' },
    { day: 'Jueves', open: '7:00 am', close: '9:00 pm' },
    { day: 'Viernes', open: '7:00 am', close: '10:00 pm' },
    { day: 'Sábado', open: '7:00 am', close: '10:00 pm' },
    { day: 'Domingo', open: '7:00 am', close: '2:00 pm' },
  ],
}

export const SETTINGS_DEFAULT = {
  acceptingOrders: true,
  modes: { pickup: true, delivery: true },
  prepMinutes: 18,
  deliveryMinutes: 22,
  deliveryFee: 3.5,
  deliveryMinimum: 15,
  taxRate: 0.115, // IVU Puerto Rico, 11.5% — rotulado como ejemplo
  pointsPerDollar: 1,
  rewardGoalPoints: 150,
  rewardValue: 10,
  busyMode: false,
}
