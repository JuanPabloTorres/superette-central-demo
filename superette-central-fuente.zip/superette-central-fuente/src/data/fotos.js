export const TAMANOS = {
  thumb: [260, 260], tile: [520, 400], card: [760, 480],
  banner: [1100, 640], hero: [760, 760], evento: [560, 380],
}

export const urlFoto = (id, size = 'thumb') => {
  if (!id) return null
  const [w, h] = TAMANOS[size] || TAMANOS.thumb
  return `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${w}&h=${h}`
}
