// ⚠️ DATOS DE EJEMPLO — el catálogo real se sube en minutos desde el panel de Negocio
export const CATEGORIAS = [
  { id: 'viveres', nombre: 'Víveres y Enlatados', icon: 'Package' },
  { id: 'carniceria', nombre: 'Carnicería y Charcutería', icon: 'Beef' },
  { id: 'lacteos', nombre: 'Lácteos y Huevos', icon: 'Milk' },
  { id: 'congelados', nombre: 'Congelados', icon: 'Snowflake' },
  { id: 'panaderia', nombre: 'Panadería', icon: 'Croissant' },
  { id: 'frutas', nombre: 'Frutas y Vegetales', icon: 'Apple' },
  { id: 'granel', nombre: 'A Granel', icon: 'Scale' },
  { id: 'bebidas', nombre: 'Bebidas', icon: 'CupSoda' },
  { id: 'snacks', nombre: 'Snacks y Dulces', icon: 'Cookie' },
  { id: 'hogar', nombre: 'Limpieza del Hogar', icon: 'SprayCan' },
  { id: 'higiene', nombre: 'Cuidado Personal', icon: 'Sparkles' },
  { id: 'ferreteria', nombre: 'Ferretería y Hogar', icon: 'Wrench' },
  { id: 'mascotas', nombre: 'Mascotas', icon: 'PawPrint' },
  { id: 'infante', nombre: 'Bebé', icon: 'Baby' },
  { id: 'salud', nombre: 'Farmacia y Salud', icon: 'Pill' },
  { id: 'licores', nombre: 'Cerveza y Licores', icon: 'Beer' },
]

// unidad: 'und' (por pieza/paquete) | 'lb' (por libra, cantidad puede ser decimal) | 'oz'
export const PRODUCTOS = [
  // Víveres y enlatados
  { id: 'viv-01', nombre: 'Arroz Sello Rojo 5 lb', categoria: 'viveres', unidad: 'und', precio: 6.49, popular: true, fotoId: 5966630, descripcion: 'Arroz blanco de grano largo, el favorito de la cocina boricua de cada día.' },
  { id: 'viv-02', nombre: 'Habichuelas rosadas enlatadas 15 oz', categoria: 'viveres', unidad: 'und', precio: 1.79, fotoId: 5966431, descripcion: 'Listas en minutos, ideales para un guisado rápido con arroz.' },
  { id: 'viv-03', nombre: 'Aceite de oliva Goya 24 oz', categoria: 'viveres', unidad: 'und', precio: 8.99, fotoId: 33783, descripcion: 'Aceite de oliva extra virgen para sofritos, ensaladas y adobos.' },
  { id: 'viv-04', nombre: 'Salsa de tomate Contadina', categoria: 'viveres', unidad: 'und', precio: 1.49, fotoId: 5966432, descripcion: 'Base espesa de tomate, perfecta para pastas y guisos.' },
  { id: 'viv-05', nombre: 'Atún Bumble Bee en agua', categoria: 'viveres', unidad: 'und', precio: 1.99, popular: true, fotoId: 12001951, descripcion: 'Atún en trozos empacado en agua, listo para ensaladas y sándwiches.' },
  { id: 'viv-06', nombre: 'Pasta espagueti 16 oz', categoria: 'viveres', unidad: 'und', precio: 1.69, fotoId: 1279330, descripcion: 'Pasta larga de trigo duro, se cocina en 10 minutos.' },
  { id: 'viv-07', nombre: 'Sazón Sofrito Goya', categoria: 'viveres', unidad: 'und', precio: 2.29, fotoId: 5966434, descripcion: 'El sabor de siempre para arroces, habichuelas y carnes.' },

  // Carnicería y charcutería
  {
    id: 'car-01', nombre: 'Pechuga de pollo', categoria: 'carniceria', unidad: 'lb', precio: 2.49, popular: true, fotoId: 8251004,
    descripcion: 'Pechuga fresca deshuesada, cortada del día en nuestra carnicería.',
    extras: [{ id: 'sazonada', nombre: 'Sazonada por la casa', precio: 0.5 }],
  },
  { id: 'car-02', nombre: 'Carne molida especial', categoria: 'carniceria', unidad: 'lb', precio: 4.99, popular: true, fotoId: 8444102, descripcion: 'Molida fresca 80/20, ideal para albóndigas, pastelón o hamburguesas.' },
  { id: 'car-03', nombre: 'Chuletas de cerdo', categoria: 'carniceria', unidad: 'lb', precio: 3.29, fotoId: 12884549, descripcion: 'Cortadas al grosor que prefieras, listas para la parrilla o freír.' },
  { id: 'car-04', nombre: 'Costillas de cerdo BBQ', categoria: 'carniceria', unidad: 'lb', precio: 3.79, fotoId: 8963030, descripcion: 'Costillar entero, perfecto para ahumar o al horno con BBQ.' },
  { id: 'car-05', nombre: 'Jamón de pierna cortado fino', categoria: 'carniceria', unidad: 'lb', precio: 5.49, fotoId: 8963031, descripcion: 'Cortado fino en el momento, ideal para sándwiches.' },
  { id: 'car-06', nombre: 'Queso de papa (de bola)', categoria: 'carniceria', unidad: 'lb', precio: 4.29, fotoId: 8963032, descripcion: 'Queso amarillo tipo bola, cortado a tu gusto.' },
  { id: 'car-07', nombre: 'Longaniza fresca', categoria: 'carniceria', unidad: 'lb', precio: 3.99, fotoId: 8963033, descripcion: 'Longaniza casera sazonada, lista para freír o asar.' },

  // Lácteos y huevos
  { id: 'lac-01', nombre: 'Leche entera Tres Monjitas 1 gal', categoria: 'lacteos', unidad: 'und', precio: 5.99, popular: true, fotoId: 3735217, descripcion: 'Leche fresca de vaca, galón entero, marca de confianza.' },
  { id: 'lac-02', nombre: 'Huevos grado A docena', categoria: 'lacteos', unidad: 'und', precio: 3.49, popular: true, fotoId: 12969328, descripcion: 'Docena de huevos grande grado A, frescos de granja local.' },
  { id: 'lac-03', nombre: 'Queso de papa amarillo en lasca', categoria: 'lacteos', unidad: 'lb', precio: 4.59, fotoId: 236011, descripcion: 'Cortado fino en lasca, ideal para sándwiches y meriendas.' },
  { id: 'lac-04', nombre: 'Mantequilla Tres Monjitas', categoria: 'lacteos', unidad: 'und', precio: 4.29, fotoId: 236012, descripcion: 'Mantequilla cremosa, perfecta para el pan de la mañana.' },
  { id: 'lac-05', nombre: 'Yogur natural 32 oz', categoria: 'lacteos', unidad: 'und', precio: 3.99, fotoId: 236013, descripcion: 'Yogur natural cremoso, envase familiar de 32 oz.' },

  // Congelados
  { id: 'con-01', nombre: 'Vegetales mixtos congelados', categoria: 'congelados', unidad: 'und', precio: 2.29, fotoId: 6941012, descripcion: 'Mezcla de vegetales lista para saltear o hervir.' },
  { id: 'con-02', nombre: 'Pastelillos de carne (12)', categoria: 'congelados', unidad: 'und', precio: 5.49, popular: true, fotoId: 6941013, descripcion: 'Docena de pastelillos rellenos de carne, listos para freír.' },
  { id: 'con-03', nombre: 'Papitas fritas congeladas', categoria: 'congelados', unidad: 'und', precio: 3.29, fotoId: 6941014, descripcion: 'Papas cortadas en tiritas, directo al horno o freidora.' },
  { id: 'con-04', nombre: 'Helado de vainilla 1.5 qt', categoria: 'congelados', unidad: 'und', precio: 4.99, fotoId: 6941015, descripcion: 'Helado cremoso de vainilla, envase familiar de 1.5 qt.' },

  // Panadería
  { id: 'pan-01', nombre: 'Pan de agua fresco', categoria: 'panaderia', unidad: 'und', precio: 1.99, popular: true, fotoId: 1775043, descripcion: 'Horneado fresco todos los días, crujiente por fuera y suave por dentro.' },
  { id: 'pan-02', nombre: 'Quesitos (docena)', categoria: 'panaderia', unidad: 'und', precio: 8.99, fotoId: 1775044, descripcion: 'Docena de quesitos de hojaldre recién horneados.' },
  { id: 'pan-03', nombre: 'Pan sobao', categoria: 'panaderia', unidad: 'und', precio: 3.49, fotoId: 1775045, descripcion: 'Pan dulce y suave, ideal para el café de la tarde.' },
  { id: 'pan-04', nombre: 'Bizcocho de vainilla porción', categoria: 'panaderia', unidad: 'und', precio: 2.49, fotoId: 1775046, descripcion: 'Porción individual de bizcocho esponjoso de vainilla.' },

  // Frutas y vegetales
  { id: 'fru-01', nombre: 'Guineos verdes', categoria: 'frutas', unidad: 'lb', precio: 0.69, popular: true, fotoId: 2255924, descripcion: 'Guineos verdes frescos, perfectos para mofongo o tostones.' },
  { id: 'fru-02', nombre: 'Aguacate maduro', categoria: 'frutas', unidad: 'und', precio: 1.79, fotoId: 557659, descripcion: 'Seleccionado en su punto justo de madurez.' },
  { id: 'fru-03', nombre: 'Tomate de ensalada', categoria: 'frutas', unidad: 'lb', precio: 1.49, fotoId: 533280, descripcion: 'Tomate fresco y jugoso, ideal para ensaladas.' },
  { id: 'fru-04', nombre: 'Cebolla amarilla', categoria: 'frutas', unidad: 'lb', precio: 0.99, fotoId: 175415, descripcion: 'Base de todo buen sofrito, fresca y firme.' },
  { id: 'fru-05', nombre: 'Yuca fresca', categoria: 'frutas', unidad: 'lb', precio: 0.89, fotoId: 2255935, descripcion: 'Yuca fresca, lista para hervir o hacer al mojo.' },
  { id: 'fru-06', nombre: 'Piña dorada', categoria: 'frutas', unidad: 'und', precio: 2.99, fotoId: 947879, descripcion: 'Piña dulce y jugosa, seleccionada por su dulzor.' },

  // A granel
  { id: 'gra-01', nombre: 'Arroz a granel', categoria: 'granel', unidad: 'lb', precio: 0.89, popular: true, fotoId: 4198696, descripcion: 'Compra solo lo que necesitas, al peso exacto.' },
  { id: 'gra-02', nombre: 'Habichuelas rosadas a granel', categoria: 'granel', unidad: 'lb', precio: 1.29, fotoId: 4198697, descripcion: 'Habichuelas secas a granel, frescas de nuestros contenedores.' },
  { id: 'gra-03', nombre: 'Café molido a granel', categoria: 'granel', unidad: 'lb', precio: 4.49, popular: true, fotoId: 4109743, descripcion: 'Café tostado y molido al momento, aroma garantizado.' },
  { id: 'gra-04', nombre: 'Habas blancas a granel', categoria: 'granel', unidad: 'lb', precio: 1.39, fotoId: 4198698, descripcion: 'Habas blancas secas, ideales para sopas y guisos.' },
  { id: 'gra-05', nombre: 'Especias variadas a granel', categoria: 'granel', unidad: 'oz', precio: 0.45, fotoId: 4198699, descripcion: 'Especias frescas al peso, compra la cantidad justa.' },

  // Bebidas
  { id: 'beb-01', nombre: 'Malta India 6-pack', categoria: 'bebidas', unidad: 'und', precio: 5.49, fotoId: 5947018, descripcion: 'Malta bien fría, six pack de latas de 12 oz.' },
  { id: 'beb-02', nombre: 'Jugo de china 64 oz', categoria: 'bebidas', unidad: 'und', precio: 3.99, popular: true, fotoId: 5947019, descripcion: 'Jugo de china natural, envase familiar de 64 oz.' },
  { id: 'beb-03', nombre: 'Agua Coamo 24-pack', categoria: 'bebidas', unidad: 'und', precio: 5.99, fotoId: 5947020, descripcion: 'Agua embotellada de manantial, paquete de 24 botellas.' },
  { id: 'beb-04', nombre: 'Refresco Coca-Cola 2 L', categoria: 'bebidas', unidad: 'und', precio: 2.79, fotoId: 5947021, descripcion: 'Botella familiar de 2 litros, bien fría en nevera.' },
  { id: 'beb-05', nombre: 'Café con leche listo 32 oz', categoria: 'bebidas', unidad: 'und', precio: 3.29, fotoId: 5947022, descripcion: 'Café con leche listo para tomar, envase de 32 oz.' },

  // Snacks y dulces
  { id: 'sna-01', nombre: 'Plátano frito (mariquitas)', categoria: 'snacks', unidad: 'und', precio: 2.49, popular: true, fotoId: 5966435, descripcion: 'Mariquitas crujientes, hechas el mismo día.' },
  { id: 'sna-02', nombre: 'Chicharrón de cerdo', categoria: 'snacks', unidad: 'und', precio: 3.99, fotoId: 5966436, descripcion: 'Chicharrón crocante, la merienda favorita de la casa.' },
  { id: 'sna-03', nombre: 'Galletas de soda', categoria: 'snacks', unidad: 'und', precio: 1.99, fotoId: 5966437, descripcion: 'Paquete familiar, perfectas con café o queso.' },
  { id: 'sna-04', nombre: 'Dulce de coco (paquete)', categoria: 'snacks', unidad: 'und', precio: 2.99, fotoId: 5966438, descripcion: 'Dulce de coco casero, paquete de varias piezas.' },

  // Limpieza del hogar
  { id: 'hog-01', nombre: 'Papel toalla 2 rollos', categoria: 'hogar', unidad: 'und', precio: 3.49, fotoId: 6621452, descripcion: 'Paquete de 2 rollos, alta absorción para la cocina.' },
  { id: 'hog-02', nombre: 'Detergente líquido 50 oz', categoria: 'hogar', unidad: 'und', precio: 6.99, fotoId: 6621453, descripcion: 'Detergente concentrado para ropa, rinde hasta 30 lavados.' },
  { id: 'hog-03', nombre: 'Papel higiénico 4 rollos', categoria: 'hogar', unidad: 'und', precio: 4.49, popular: true, fotoId: 6621454, descripcion: 'Paquete de 4 rollos, doble hoja suave.' },
  { id: 'hog-04', nombre: 'Desinfectante multiusos en spray', categoria: 'hogar', unidad: 'und', precio: 4.79, descripcion: 'Elimina 99.9% de gérmenes en superficies de cocina y baño.' },
  { id: 'hog-05', nombre: 'Esponjas de fregar (paquete 3)', categoria: 'hogar', unidad: 'und', precio: 2.29, descripcion: 'Esponjas dobles, un lado suave y otro para lo difícil.' },

  // Cuidado personal
  { id: 'hig-01', nombre: 'Shampoo anticaspa 400 ml', categoria: 'higiene', unidad: 'und', precio: 4.99, fotoId: 7148533, descripcion: 'Limpieza profunda para el cuero cabelludo, uso diario.' },
  { id: 'hig-02', nombre: 'Pasta y cepillo dental', categoria: 'higiene', unidad: 'und', precio: 3.29, popular: true, fotoId: 7622555, descripcion: 'Combo de pasta dental y cepillo de cerdas suaves.' },
  { id: 'hig-03', nombre: 'Desodorante en barra', categoria: 'higiene', unidad: 'und', precio: 2.99, fotoId: 30353208, descripcion: 'Protección de 48 horas, fórmula sin manchas.' },
  { id: 'hig-04', nombre: 'Jabón de baño (paquete de 3)', categoria: 'higiene', unidad: 'und', precio: 3.29, fotoId: 6621455, descripcion: 'Paquete de 3 jabones de tocador, aroma fresco.' },
  { id: 'hig-05', nombre: 'Afeitadoras desechables (paquete 4)', categoria: 'higiene', unidad: 'und', precio: 2.49, fotoId: 9456810, descripcion: 'Afeitadoras de doble hoja, paquete de 4 unidades.' },

  // Ferretería y hogar
  { id: 'fer-01', nombre: 'Bombilla LED 60W equivalente', categoria: 'ferreteria', unidad: 'und', precio: 4.99, fotoId: 577514, descripcion: 'Bombilla LED de bajo consumo, luz blanca cálida.' },
  { id: 'fer-02', nombre: 'Pilas AA (paquete de 4)', categoria: 'ferreteria', unidad: 'und', precio: 3.49, popular: true, fotoId: 3639037, descripcion: 'Pilas alcalinas de larga duración, paquete de 4.' },
  { id: 'fer-03', nombre: 'Candado de seguridad 40mm', categoria: 'ferreteria', unidad: 'und', precio: 6.99, fotoId: 157203, descripcion: 'Candado resistente a la intemperie, incluye dos llaves.' },
  { id: 'fer-04', nombre: 'Guantes de trabajo (par)', categoria: 'ferreteria', unidad: 'und', precio: 3.99, fotoId: 7362896, descripcion: 'Guantes reforzados para trabajos de jardín y taller.' },
  { id: 'fer-05', nombre: 'Martillo de carpintero 16 oz', categoria: 'ferreteria', unidad: 'und', precio: 8.49, fotoId: 27084600, descripcion: 'Cabeza de acero forjado, mango antideslizante.' },
  { id: 'fer-06', nombre: 'Cinta métrica 25 pies', categoria: 'ferreteria', unidad: 'und', precio: 5.49, fotoId: 5383194, descripcion: 'Cinta métrica retráctil con freno y clip de cinturón.' },
  { id: 'fer-07', nombre: 'Cinta adhesiva multiuso', categoria: 'ferreteria', unidad: 'und', precio: 2.99, fotoId: 7217806, descripcion: 'Cinta resistente para reparaciones rápidas en casa.' },

  // Mascotas
  { id: 'mas-01', nombre: 'Alimento seco para perro 5 lb', categoria: 'mascotas', unidad: 'und', precio: 9.99, popular: true, fotoId: 8434633, descripcion: 'Fórmula completa balanceada para perros adultos.' },
  { id: 'mas-02', nombre: 'Alimento para gato 3 lb', categoria: 'mascotas', unidad: 'und', precio: 7.49, fotoId: 27130348, descripcion: 'Croquetas con sabor a pescado, nutrición completa para gatos.' },
  { id: 'mas-03', nombre: 'Correa para perro', categoria: 'mascotas', unidad: 'und', precio: 5.99, fotoId: 7800873, descripcion: 'Correa ajustable resistente, ideal para paseos diarios.' },
  { id: 'mas-04', nombre: 'Arena sanitaria para gato', categoria: 'mascotas', unidad: 'und', precio: 6.49, descripcion: 'Arena aglomerante con control de olores.' },

  // Bebé
  { id: 'inf-01', nombre: 'Pañales talla 3 (paquete)', categoria: 'infante', unidad: 'und', precio: 12.99, popular: true, fotoId: 28846860, descripcion: 'Paquete de pañales suaves con indicador de humedad.' },
  { id: 'inf-02', nombre: 'Fórmula infantil en polvo', categoria: 'infante', unidad: 'und', precio: 18.99, fotoId: 41222, descripcion: 'Fórmula infantil completa desde los primeros meses.' },
  { id: 'inf-03', nombre: 'Toallitas húmedas para bebé', categoria: 'infante', unidad: 'und', precio: 2.99, descripcion: 'Toallitas suaves hipoalergénicas, paquete de repuesto.' },
  { id: 'inf-04', nombre: 'Talco para bebé', categoria: 'infante', unidad: 'und', precio: 2.49, descripcion: 'Talco suave para mantener la piel del bebé seca.' },

  // Farmacia y salud
  { id: 'sal-01', nombre: 'Multivitamínico (frasco)', categoria: 'salud', unidad: 'und', precio: 9.99, fotoId: 17820735, descripcion: 'Complejo multivitamínico diario para toda la familia.' },
  { id: 'sal-02', nombre: 'Curitas surtidas', categoria: 'salud', unidad: 'und', precio: 2.99, fotoId: 9255018, descripcion: 'Caja de curitas en tamaños surtidos para el botiquín.' },
  { id: 'sal-03', nombre: 'Gel antibacterial de manos', categoria: 'salud', unidad: 'und', precio: 2.49, popular: true, fotoId: 8266821, descripcion: 'Gel antibacterial 70% alcohol, tamaño de bolsillo.' },
  { id: 'sal-04', nombre: 'Analgésico en tabletas', categoria: 'salud', unidad: 'und', precio: 4.99, fotoId: 3683088, descripcion: 'Alivio para dolor de cabeza y fiebre, frasco de 24 tabletas.' },

  // Cerveza y licores
  { id: 'lic-01', nombre: 'Medalla Light 12-pack', categoria: 'licores', unidad: 'und', precio: 12.99, popular: true, fotoId: 5946978, descripcion: 'La cerveza de Puerto Rico, doce latas bien frías.' },
  { id: 'lic-02', nombre: 'Ron Don Q Cristal 750 ml', categoria: 'licores', unidad: 'und', precio: 11.49, fotoId: 5946979, descripcion: 'Ron blanco puertorriqueño, botella de 750 ml.' },
  { id: 'lic-03', nombre: 'Corona Extra 6-pack', categoria: 'licores', unidad: 'und', precio: 8.99, fotoId: 5946980, descripcion: 'Six pack de Corona Extra, ideal para la parrillada.' },
]

export const productosPorCategoria = (catId) => PRODUCTOS.filter((p) => p.categoria === catId)
export const productoPorId = (id) => PRODUCTOS.find((p) => p.id === id)
export const productosPopulares = () => PRODUCTOS.filter((p) => p.popular)
