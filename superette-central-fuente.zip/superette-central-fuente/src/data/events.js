// ⚠️ DATOS DE EJEMPLO
export const EVENTOS = [
  {
    id: 'ev-1',
    titulo: 'Muestra de café local',
    fecha: 'Sábado, 10:00 am',
    resumen: 'Prueba gratis el café molido a granel con un torrefactor de la zona.',
    fotoId: 4109743,
  },
  {
    id: 'ev-2',
    titulo: 'Noche de parrilla',
    fecha: 'Viernes, 4:00 pm',
    resumen: 'Descuentos especiales en carnes para la parrilla del fin de semana.',
    fotoId: 8963029,
  },
  {
    id: 'ev-3',
    titulo: 'Día del Cliente Frecuente',
    fecha: 'Último domingo del mes',
    resumen: 'Doble de puntos de recompensa para clientes inscritos.',
    fotoId: 5966630,
  },
]
