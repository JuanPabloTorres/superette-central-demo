import { createContext, useContext, useEffect, useMemo, useReducer, useState } from 'react'
import { SETTINGS_DEFAULT } from '../data/config.js'
import { PROMOS } from '../data/promos.js'
import { PRODUCTOS } from '../data/catalogo.js'
import { seedOrders, seedCustomers } from './seed.js'
import { computeTotals } from './pricing.js'
import { loadState, saveState } from '../lib/storage.js'

const MY_CUSTOMER_ID = 'demo-cliente'

export const FLOW = {
  pickup: ['recibido', 'preparando', 'empacado', 'listo'],
  delivery: ['recibido', 'preparando', 'empacado', 'en_camino', 'entregado'],
}

export const STATUS_LABEL = {
  recibido: 'Recibido',
  preparando: 'Preparando tu compra',
  empacado: 'Empacado',
  listo: 'Listo para recoger',
  en_camino: 'En camino',
  entregado: 'Entregado',
}

export const STATUS_SHORT = {
  recibido: 'Nuevo',
  preparando: 'Preparando',
  empacado: 'Empacado',
  listo: 'Listo',
  en_camino: 'En camino',
  entregado: 'Entregado',
}

export const BOARD_COLUMNS = [
  { key: 'recibido', label: 'Nuevos', estados: ['recibido'] },
  { key: 'empacando', label: 'Empacando', estados: ['preparando', 'empacado'] },
  { key: 'listo', label: 'Listos', estados: ['listo', 'en_camino'] },
]

const NOTIF_POR_ESTADO = {
  recibido: { kind: 'info', title: 'Pedido recibido', body: (c) => `Recibimos tu pedido ${c}. Ya lo estamos preparando.` },
  preparando: { kind: 'info', title: 'Preparando tu compra', body: (c) => `Estamos armando tu pedido ${c}.` },
  empacado: { kind: 'success', title: 'Pedido empacado', body: (c) => `Tu pedido ${c} está empacado y listo para el siguiente paso.` },
  listo: { kind: 'success', title: '¡Listo para recoger!', body: (c) => `Tu pedido ${c} te espera en el mostrador.` },
  en_camino: { kind: 'info', title: 'En camino', body: (c) => `Tu pedido ${c} salió en camino a tu dirección.` },
  entregado: { kind: 'success', title: 'Entregado', body: (c) => `Tu pedido ${c} fue entregado. ¡Gracias por comprar con nosotros!` },
}

function initialState() {
  const orders = seedOrders(MY_CUSTOMER_ID)
  const customers = seedCustomers(MY_CUSTOMER_ID)
  const myOrderIds = orders.filter((o) => o.customerId === MY_CUSTOMER_ID).map((o) => o.id)
  return {
    loggedIn: true,
    account: { id: MY_CUSTOMER_ID, name: 'Tu compra', phone: '787-555-0100', email: '', address: 'Bo. Hato Puerco, Villalba' },
    cart: [],
    cartMode: 'pickup',
    scheduledFor: null,
    promoId: null,
    rewardRedeem: false,
    orders,
    myOrderIds,
    counter: 3300,
    customers,
    prices: {},
    availability: Object.fromEntries(PRODUCTOS.map((p) => [p.id, true])),
    promoOverrides: {},
    settings: { ...SETTINGS_DEFAULT },
    notifications: orders
      .filter((o) => o.customerId === MY_CUSTOMER_ID && o.status !== 'recibido')
      .map((o, i) => ({
        id: `seed-notif-${i}`,
        kind: NOTIF_POR_ESTADO[o.status]?.kind || 'info',
        title: NOTIF_POR_ESTADO[o.status]?.title || 'Actualización',
        body: NOTIF_POR_ESTADO[o.status]?.body(o.code) || '',
        at: o.statusHistory[o.statusHistory.length - 1]?.at || o.createdAt,
        read: o.status === 'entregado',
        orderId: o.id,
      })),
    toasts: [],
    kdsSeen: [],
    favorites: ['viv-01', 'car-01', 'gra-03'],
  }
}

function reducer(state, action) {
  switch (action.type) {
    case 'HYDRATE':
      return { ...initialState(), ...action.payload }

    case 'ADD_TO_CART': {
      const { productId, cantidad, extras, nota } = action.payload
      const existing = state.cart.find(
        (i) => i.productId === productId && JSON.stringify(i.extras) === JSON.stringify(extras) && i.nota === nota
      )
      let cart
      if (existing) {
        cart = state.cart.map((i) => (i === existing ? { ...i, cantidad: i.cantidad + cantidad } : i))
      } else {
        cart = [...state.cart, { productId, cantidad, extras, nota }]
      }
      return { ...state, cart }
    }

    case 'SET_QTY': {
      const { index, cantidad } = action.payload
      if (cantidad <= 0) return { ...state, cart: state.cart.filter((_, i) => i !== index) }
      return { ...state, cart: state.cart.map((it, i) => (i === index ? { ...it, cantidad } : it)) }
    }

    case 'REMOVE_ITEM':
      return { ...state, cart: state.cart.filter((_, i) => i !== action.payload.index) }

    case 'CLEAR_CART':
      return { ...state, cart: [], promoId: null, rewardRedeem: false }

    case 'SET_CART_MODE':
      return { ...state, cartMode: action.payload }

    case 'APPLY_PROMO':
      return { ...state, promoId: action.payload }

    case 'SET_REWARD':
      return { ...state, rewardRedeem: action.payload }

    case 'PLACE_ORDER': {
      const code = `PD-${state.counter + 1}`
      const createdAt = action.payload?.createdAt || Date.now()
      const mode = state.cartMode
      const eta = createdAt + (mode === 'delivery' ? state.settings.prepMinutes + state.settings.deliveryMinutes : state.settings.prepMinutes) * 60000
      const order = {
        id: `order-${createdAt}`,
        code,
        customerId: state.account.id,
        customerName: state.account.name,
        mode,
        status: 'recibido',
        statusHistory: [{ status: 'recibido', at: createdAt }],
        items: state.cart,
        promoId: state.promoId,
        rewardRedeem: state.rewardRedeem,
        createdAt,
        eta,
        address: mode === 'delivery' ? state.account.address : null,
        notes: action.payload?.notes || '',
      }
      return {
        ...state,
        orders: [order, ...state.orders],
        myOrderIds: [order.id, ...state.myOrderIds],
        counter: state.counter + 1,
        cart: [],
        promoId: null,
        rewardRedeem: false,
      }
    }

    case 'SET_STATUS': {
      const { orderId } = action.payload
      const order = state.orders.find((o) => o.id === orderId)
      if (!order) return state
      const chain = FLOW[order.mode]
      const idx = chain.indexOf(order.status)
      const next = chain[Math.min(idx + 1, chain.length - 1)]
      if (next === order.status) return state
      const at = Date.now()
      const orders = state.orders.map((o) =>
        o.id === orderId ? { ...o, status: next, statusHistory: [...o.statusHistory, { status: next, at }] } : o
      )
      let notifications = state.notifications
      let toasts = state.toasts
      if (state.myOrderIds.includes(orderId)) {
        const n = NOTIF_POR_ESTADO[next]
        if (n) {
          const notif = { id: `notif-${at}`, kind: n.kind, title: n.title, body: n.body(order.code), at, read: false, orderId }
          notifications = [notif, ...notifications]
          toasts = [...toasts, { id: `toast-${at}`, message: n.title, tone: n.kind }]
        }
      }
      return { ...state, orders, notifications, toasts }
    }

    case 'CANCEL_ORDER':
      return {
        ...state,
        orders: state.orders.map((o) => (o.id === action.payload.orderId ? { ...o, status: 'cancelado' } : o)),
      }

    case 'SET_AVAILABILITY':
      return { ...state, availability: { ...state.availability, [action.payload.productId]: action.payload.value } }

    case 'SET_PRICE':
      return { ...state, prices: { ...state.prices, [action.payload.productId]: action.payload.value } }

    case 'TOGGLE_PROMO': {
      const cur = state.promoOverrides[action.payload.promoId] || {}
      return {
        ...state,
        promoOverrides: {
          ...state.promoOverrides,
          [action.payload.promoId]: { ...cur, activa: !(cur.activa ?? PROMOS.find((p) => p.id === action.payload.promoId)?.activa) },
        },
      }
    }

    case 'FEATURE_PROMO': {
      const overrides = {}
      PROMOS.forEach((p) => { overrides[p.id] = { ...(state.promoOverrides[p.id] || {}), destacada: p.id === action.payload.promoId } })
      return { ...state, promoOverrides: { ...state.promoOverrides, ...overrides } }
    }

    case 'SET_SETTINGS':
      return { ...state, settings: { ...state.settings, ...action.payload } }

    case 'LOGIN':
      return { ...state, loggedIn: true }

    case 'LOGOUT':
      return { ...state, loggedIn: false }

    case 'TOGGLE_FAVORITE': {
      const has = state.favorites.includes(action.payload.productId)
      return { ...state, favorites: has ? state.favorites.filter((id) => id !== action.payload.productId) : [...state.favorites, action.payload.productId] }
    }

    case 'MARK_SEEN':
      return { ...state, kdsSeen: [...new Set([...state.kdsSeen, action.payload.orderId])] }

    case 'READ_NOTIFICATIONS':
      return { ...state, notifications: state.notifications.map((n) => ({ ...n, read: true })) }

    case 'TOAST':
      return { ...state, toasts: [...state.toasts, { id: `toast-${Date.now()}-${Math.random()}`, ...action.payload }] }

    case 'DISMISS_TOAST':
      return { ...state, toasts: state.toasts.filter((t) => t.id !== action.payload.id) }

    case 'RESET':
      return initialState()

    default:
      return state
  }
}

const DemoContext = createContext(null)

export function DemoProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, undefined, initialState)

  useEffect(() => {
    const saved = loadState()
    if (saved) dispatch({ type: 'HYDRATE', payload: saved })
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useEffect(() => {
    saveState(state)
  }, [state])

  const api = useMemo(() => ({
    addToCart: (productId, cantidad, extras = [], nota = '') => dispatch({ type: 'ADD_TO_CART', payload: { productId, cantidad, extras, nota } }),
    setQty: (index, cantidad) => dispatch({ type: 'SET_QTY', payload: { index, cantidad } }),
    removeItem: (index) => dispatch({ type: 'REMOVE_ITEM', payload: { index } }),
    clearCart: () => dispatch({ type: 'CLEAR_CART' }),
    setCartMode: (mode) => dispatch({ type: 'SET_CART_MODE', payload: mode }),
    applyPromo: (promoId) => dispatch({ type: 'APPLY_PROMO', payload: promoId }),
    setReward: (v) => dispatch({ type: 'SET_REWARD', payload: v }),
    placeOrder: (extra) => {
      const createdAt = Date.now()
      dispatch({ type: 'PLACE_ORDER', payload: { ...extra, createdAt } })
      return `order-${createdAt}`
    },
    setStatus: (orderId) => dispatch({ type: 'SET_STATUS', payload: { orderId } }),
    cancelOrder: (orderId) => dispatch({ type: 'CANCEL_ORDER', payload: { orderId } }),
    setAvailability: (productId, value) => dispatch({ type: 'SET_AVAILABILITY', payload: { productId, value } }),
    setPrice: (productId, value) => dispatch({ type: 'SET_PRICE', payload: { productId, value } }),
    togglePromo: (promoId) => dispatch({ type: 'TOGGLE_PROMO', payload: { promoId } }),
    featurePromo: (promoId) => dispatch({ type: 'FEATURE_PROMO', payload: { promoId } }),
    setSettings: (payload) => dispatch({ type: 'SET_SETTINGS', payload }),
    login: () => dispatch({ type: 'LOGIN' }),
    logout: () => dispatch({ type: 'LOGOUT' }),
    toggleFavorite: (productId) => dispatch({ type: 'TOGGLE_FAVORITE', payload: { productId } }),
    markSeen: (orderId) => dispatch({ type: 'MARK_SEEN', payload: { orderId } }),
    readNotifications: () => dispatch({ type: 'READ_NOTIFICATIONS' }),
    pushNotification: (payload) => dispatch({ type: 'TOAST', payload }),
    toast: (message, tone = 'info') => dispatch({ type: 'TOAST', payload: { message, tone } }),
    dismissToast: (id) => dispatch({ type: 'DISMISS_TOAST', payload: { id } }),
    reset: () => dispatch({ type: 'RESET' }),
  }), [])

  const value = useMemo(() => ({ state, dispatch, ...api }), [state, api])

  return <DemoContext.Provider value={value}>{children}</DemoContext.Provider>
}

export function useDemo() {
  const ctx = useContext(DemoContext)
  if (!ctx) throw new Error('useDemo debe usarse dentro de DemoProvider')
  return ctx
}

export function useNow(intervalMs = 5000) {
  const [now, setNow] = useState(Date.now())
  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), intervalMs)
    return () => clearInterval(id)
  }, [intervalMs])
  return now
}

export function useCartTotals(mode) {
  const { state } = useDemo()
  return useMemo(
    () => computeTotals({ cart: state.cart, promoId: state.promoId, prices: state.prices, settings: state.settings, mode: mode || state.cartMode, rewardRedeem: state.rewardRedeem }),
    [state.cart, state.promoId, state.prices, state.settings, state.cartMode, state.rewardRedeem, mode]
  )
}

export function useCartCount() {
  const { state } = useDemo()
  return state.cart.reduce((sum, i) => sum + i.cantidad, 0)
}

export function myActiveOrder(state) {
  return state.orders.find((o) => state.myOrderIds.includes(o.id) && o.status !== 'entregado' && o.status !== 'cancelado')
}

export { MY_CUSTOMER_ID }
