import { PRODUCTOS } from '../data/catalogo.js'

const minsAgo = (m) => Date.now() - m * 60000

function pick(arr, n) {
  const copy = [...arr]
  const out = []
  for (let i = 0; i < n && copy.length; i++) {
    out.push(copy.splice(Math.floor(Math.random() * copy.length), 1)[0])
  }
  return out
}

function itemsFrom(productIds) {
  return productIds.map((id) => {
    const p = PRODUCTOS.find((x) => x.id === id)
    const cantidad = p.unidad === 'lb' ? [1, 1.5, 2, 2.5, 3][Math.floor(Math.random() * 5)] : Math.ceil(Math.random() * 3)
    return { productId: id, cantidad, extras: [], nota: '' }
  })
}

function buildStatusHistory(mode, currentStatus, createdAt) {
  const chain = mode === 'delivery'
    ? ['recibido', 'preparando', 'empacado', 'en_camino', 'entregado']
    : ['recibido', 'preparando', 'empacado', 'listo']
  const idx = chain.indexOf(currentStatus)
  const end = Date.now()
  const span = end - createdAt
  const steps = idx + 1
  const history = []
  for (let i = 0; i < steps; i++) {
    history.push({ status: chain[i], at: createdAt + Math.round((span * i) / Math.max(1, steps)) })
  }
  return history
}

const NOMBRES = ['Carmen Rivera', 'José Colón', 'Wanda Ortiz', 'Luis Meléndez', 'Ivelisse Torres', 'Ángel Ramos', 'Yolanda Reyes', 'Héctor Vega', 'Marisol Cruz', 'Rafael Santos']

export function seedOrders(myCustomerId) {
  const specs = [
    { mode: 'pickup', status: 'recibido', minsAgo: 3 },
    { mode: 'delivery', status: 'recibido', minsAgo: 6 },
    { mode: 'pickup', status: 'preparando', minsAgo: 12 },
    { mode: 'delivery', status: 'preparando', minsAgo: 15 },
    { mode: 'pickup', status: 'empacado', minsAgo: 20 },
    { mode: 'delivery', status: 'empacado', minsAgo: 24 },
    { mode: 'pickup', status: 'listo', minsAgo: 30 },
    { mode: 'delivery', status: 'en_camino', minsAgo: 28 },
    { mode: 'delivery', status: 'entregado', minsAgo: 90 },
    { mode: 'pickup', status: 'entregado', minsAgo: 150 },
    { mode: 'pickup', status: 'entregado', minsAgo: 300 },
    { mode: 'delivery', status: 'entregado', minsAgo: 1440 },
  ]

  return specs.map((spec, i) => {
    const createdAt = minsAgo(spec.minsAgo)
    const isMine = i === 0 || i === 6 || i === 9
    const items = itemsFrom(pick(PRODUCTOS.map((p) => p.id), 2 + Math.floor(Math.random() * 3)))
    return {
      id: `seed-${i}`,
      code: `PD-${3200 + i}`,
      customerId: isMine ? myCustomerId : `cliente-${i}`,
      customerName: isMine ? 'Tu compra' : NOMBRES[i % NOMBRES.length],
      mode: spec.mode,
      status: spec.status,
      statusHistory: buildStatusHistory(spec.mode, spec.status, createdAt),
      items,
      promoId: i % 4 === 0 ? 'oferta-viernes' : null,
      rewardRedeem: false,
      createdAt,
      eta: createdAt + 30 * 60000,
      address: spec.mode === 'delivery' ? 'Bo. Hato Puerco, Villalba' : null,
      notes: '',
    }
  })
}

export function seedCustomers(myCustomerId) {
  const base = NOMBRES.map((nombre, i) => ({
    id: `cliente-${i}`,
    nombre,
    telefono: `787-${(500 + i * 7).toString().padStart(3, '0')}-${(1000 + i * 11).toString().slice(-4)}`,
    puntos: Math.floor(Math.random() * 140),
    totalGastado: Math.round((80 + Math.random() * 420) * 100) / 100,
  }))
  base.push({ id: myCustomerId, nombre: 'Tu compra', telefono: '787-555-0100', puntos: 42, totalGastado: 96.5 })
  return base
}
