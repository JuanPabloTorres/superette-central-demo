import { productoPorId } from '../data/catalogo.js'
import { PROMOS } from '../data/promos.js'

const r2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100

export function basePrice(productId, prices = {}) {
  const producto = productoPorId(productId)
  if (!producto) return 0
  return prices[productId] ?? producto.precio
}

export function unitPrice(productId, extraIds = [], prices = {}) {
  const producto = productoPorId(productId)
  if (!producto) return 0
  const base = basePrice(productId, prices)
  const extrasTotal = (producto.extras || [])
    .filter((e) => extraIds.includes(e.id))
    .reduce((sum, e) => sum + e.precio, 0)
  return r2(base + extrasTotal)
}

export function describeItem(item) {
  const producto = productoPorId(item.productId)
  if (!producto) return []
  const lineas = []
  const unidadLabel = producto.unidad === 'lb' ? 'lb' : producto.unidad === 'oz' ? 'oz' : 'und'
  lineas.push(`${item.cantidad} ${unidadLabel}`)
  ;(producto.extras || [])
    .filter((e) => (item.extras || []).includes(e.id))
    .forEach((e) => lineas.push(`+ ${e.nombre}`))
  if (item.nota) lineas.push(`Nota: ${item.nota}`)
  return lineas
}

export function lineTotal(item, prices = {}) {
  return r2(unitPrice(item.productId, item.extras, prices) * item.cantidad)
}

export function cartSubtotal(cart, prices = {}) {
  return r2(cart.reduce((sum, item) => sum + lineTotal(item, prices), 0))
}

function promoDiscount(promo, cart, prices) {
  if (!promo) return 0
  const elegible = promo.aplicaA === 'todas'
    ? cart
    : cart.filter((item) => promo.aplicaA.includes(productoPorId(item.productId)?.categoria))
  const baseElegible = r2(elegible.reduce((sum, item) => sum + lineTotal(item, prices), 0))
  const subtotalTotal = cartSubtotal(cart, prices)
  if (subtotalTotal < (promo.minimo || 0)) return 0
  if (promo.tipo === 'percent') return r2(baseElegible * (promo.valor / 100))
  return Math.min(promo.valor, baseElegible)
}

export function computeTotals({ cart, promoId, prices = {}, settings, mode = 'pickup', rewardRedeem = false }) {
  const subtotal = cartSubtotal(cart, prices)
  const promo = promoId ? PROMOS.find((p) => p.id === promoId) : null
  let discount = promoDiscount(promo, cart, prices)

  let rewardDiscount = 0
  if (rewardRedeem && settings) {
    rewardDiscount = Math.min(settings.rewardValue, subtotal - discount)
  }
  discount = r2(Math.min(discount + rewardDiscount, subtotal))

  const taxableBase = r2(Math.max(0, subtotal - discount))
  const tax = r2(taxableBase * (settings?.taxRate ?? 0))

  const fee = mode === 'delivery' ? r2(settings?.deliveryFee ?? 0) : 0

  const total = r2(taxableBase + tax + fee)
  const points = Math.max(0, Math.floor(taxableBase * (settings?.pointsPerDollar ?? 0)))

  return { subtotal, discount, rewardDiscount, tax, fee, total, points, promo }
}
