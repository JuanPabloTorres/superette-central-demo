import { Link } from 'react-router-dom'
import { RotateCcw, ShoppingBasket } from 'lucide-react'
import { useDemo, STATUS_SHORT } from '../store/DemoStore.jsx'
import { Contenedor, PageHeader, SectionHeader } from '../shell/Layout.jsx'
import { Tarjeta, Badge, Button, EmptyState } from '../ui/index.jsx'
import { dayLabel, money } from '../lib/format.js'
import { lineTotal } from '../store/pricing.js'

export default function MisOrdenes() {
  const { state, addToCart, toast } = useDemo()
  const mias = state.orders.filter((o) => state.myOrderIds.includes(o.id)).sort((a, b) => b.createdAt - a.createdAt)
  const enCurso = mias.filter((o) => o.status !== 'entregado' && o.status !== 'cancelado')
  const historial = mias.filter((o) => o.status === 'entregado' || o.status === 'cancelado')

  const repetir = (orden) => {
    orden.items.forEach((it) => addToCart(it.productId, it.cantidad, it.extras, it.nota))
    toast('Agregamos los mismos productos a tu carrito', 'success')
  }

  return (
    <Contenedor>
      <PageHeader title="Mis pedidos" />

      <SectionHeader title="En curso" />
      {enCurso.length === 0 ? (
        <EmptyState icon={ShoppingBasket} title="No tienes pedidos en curso." action={<Button as={Link} to="/catalogo" variant="primary">Empezar mi compra</Button>} />
      ) : (
        <div className="space-y-3">
          {enCurso.map((o) => <FilaOrden key={o.id} orden={o} prices={state.prices} />)}
        </div>
      )}

      <SectionHeader title="Historial" />
      {historial.length === 0 ? (
        <EmptyState icon={ShoppingBasket} title="Todavía no tienes compras anteriores." />
      ) : (
        <div className="space-y-3">
          {historial.map((o) => (
            <FilaOrden key={o.id} orden={o} prices={state.prices} onRepetir={() => repetir(o)} />
          ))}
        </div>
      )}
    </Contenedor>
  )
}

function FilaOrden({ orden, prices, onRepetir }) {
  const total = orden.items.reduce((s, it) => s + lineTotal(it, prices), 0)
  return (
    <Tarjeta className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:justify-between">
      <Link to={`/orden/${orden.id}`} className="min-w-0">
        <p className="font-bold text-tinta-800">{orden.code} <Badge tone={orden.status === 'entregado' ? 'green' : 'amber'} className="ml-2">{STATUS_SHORT[orden.status]}</Badge></p>
        <p className="text-xs text-tinta-400">{dayLabel(orden.createdAt)} · {orden.mode === 'delivery' ? 'Entrega' : 'Recoger en tienda'} · {money(total)}</p>
      </Link>
      {onRepetir && (
        <Button variant="soft" size="sm" onClick={onRepetir}><RotateCcw size={14} /> Repetir</Button>
      )}
    </Tarjeta>
  )
}
