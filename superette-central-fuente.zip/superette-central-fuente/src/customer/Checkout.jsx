import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import { Store, Truck, Clock, CreditCard, ShieldCheck } from 'lucide-react'
import { useDemo, useCartTotals } from '../store/DemoStore.jsx'
import { Contenedor, PageHeader } from '../shell/Layout.jsx'
import { Tarjeta, Button, Radio, Field, Input, Textarea } from '../ui/index.jsx'
import { money } from '../lib/format.js'

export default function Checkout() {
  const { state, setCartMode, placeOrder } = useDemo()
  const navigate = useNavigate()
  const totals = useCartTotals(state.cartMode)
  const [cuando, setCuando] = useState('ahora')
  const [pago, setPago] = useState('tarjeta')
  const [notas, setNotas] = useState('')

  // Se revisa solo al montar: evita que el pedido recién confirmado
  // (que vacía el carrito) nos rebote de vuelta al catálogo.
  useEffect(() => {
    if (state.cart.length === 0) navigate('/catalogo')
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const confirmar = () => {
    const orderId = placeOrder({ notes: notas })
    navigate(`/orden/${orderId}`)
  }

  return (
    <Contenedor ancho="angosto">
      <PageHeader title="Confirmar compra" sub="Cuatro pasos rápidos, sin formularios largos." />

      <Paso n={1} titulo="¿Cómo la quieres recibir?">
        <div className="space-y-2">
          <Radio
            label="Recoger en tienda"
            right={`Listo en ~${state.settings.prepMinutes} min`}
            name="modo"
            checked={state.cartMode === 'pickup'}
            onChange={() => setCartMode('pickup')}
          />
          <Radio
            label="Entrega a domicilio"
            right={`+${money(state.settings.deliveryFee)}`}
            name="modo"
            checked={state.cartMode === 'delivery'}
            onChange={() => setCartMode('delivery')}
          />
          {state.cartMode === 'delivery' && (
            <p className="text-xs text-tinta-400">Mínimo de compra para entrega: {money(state.settings.deliveryMinimum)}.</p>
          )}
        </div>
      </Paso>

      <Paso n={2} titulo="Tus datos">
        <div className="grid gap-3 sm:grid-cols-2">
          <Field label="Nombre"><Input defaultValue={state.account.name} readOnly /></Field>
          <Field label="Teléfono"><Input defaultValue={state.account.phone} readOnly /></Field>
        </div>
        {state.cartMode === 'delivery' && (
          <Field label="Dirección de entrega" className="mt-3"><Input defaultValue={state.account.address} readOnly /></Field>
        )}
        <Field label="Nota para el negocio (opcional)" className="mt-3">
          <Textarea value={notas} onChange={(e) => setNotas(e.target.value)} placeholder="Ej. tocar el timbre, sustituir producto si falta…" />
        </Field>
      </Paso>

      <Paso n={3} titulo="¿Para cuándo?">
        <div className="space-y-2">
          <Radio label="Lo antes posible" right="Recomendado" name="cuando" checked={cuando === 'ahora'} onChange={() => setCuando('ahora')} />
          <Radio label="Programar para más tarde" name="cuando" checked={cuando === 'programado'} onChange={() => setCuando('programado')} />
        </div>
      </Paso>

      <Paso n={4} titulo="Método de pago">
        <div className="space-y-2">
          <Radio label="Tarjeta de débito/crédito" name="pago" checked={pago === 'tarjeta'} onChange={() => setPago('tarjeta')} />
          <Radio label="Efectivo al recibir/recoger" name="pago" checked={pago === 'efectivo'} onChange={() => setPago('efectivo')} />
        </div>
        <p className="mt-3 flex items-center gap-2 rounded-xl bg-papel-100 p-3 text-xs text-tinta-500">
          <ShieldCheck size={16} className="shrink-0 text-oliva-600" /> Esta es una demostración: ningún pago real se procesa aquí.
        </p>
      </Paso>

      <Tarjeta className="mt-6 space-y-2 p-5">
        <Fila label="Subtotal" value={money(totals.subtotal)} />
        {totals.discount > 0 && <Fila label="Descuento" value={`-${money(totals.discount)}`} tone="text-oliva-600" />}
        <Fila label="Impuesto" value={money(totals.tax)} />
        {state.cartMode === 'delivery' && <Fila label="Entrega" value={money(totals.fee)} />}
        <div className="my-1 h-px bg-papel-200" />
        <Fila label="Total" value={money(totals.total)} big />
      </Tarjeta>

      <Button variant="primary" size="lg" className="mt-4 w-full" onClick={confirmar}>
        Confirmar pedido
      </Button>
    </Contenedor>
  )
}

function Paso({ n, titulo, children }) {
  return (
    <Tarjeta className="mt-4 p-5">
      <div className="mb-3 flex items-center gap-3">
        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-verde-600 font-display text-sm text-papel-50">{n}</span>
        <h3 className="font-display uppercase tracking-wide text-tinta-900">{titulo}</h3>
      </div>
      {children}
    </Tarjeta>
  )
}

function Fila({ label, value, tone = 'text-tinta-700', big }) {
  return (
    <div className="flex items-center justify-between">
      <span className={big ? 'font-display uppercase tracking-wide text-tinta-900' : 'text-sm text-tinta-500'}>{label}</span>
      <span className={big ? `font-display text-xl ${tone}` : `text-sm font-semibold ${tone}`}>{value}</span>
    </div>
  )
}
