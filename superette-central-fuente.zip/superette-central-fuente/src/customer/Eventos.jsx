import { EVENTOS } from '../data/events.js'
import { Contenedor, PageHeader } from '../shell/Layout.jsx'
import { Tarjeta } from '../ui/index.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'

export default function Eventos() {
  return (
    <Contenedor>
      <PageHeader title="Eventos" sub="Lo que pasa esta semana en el negocio." />
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {EVENTOS.map((e) => (
          <Tarjeta key={e.id} hover className="overflow-hidden">
            <FoodArt fotoId={e.fotoId} size="evento" className="h-40 w-full" />
            <div className="space-y-1 p-4">
              <p className="text-xs font-bold uppercase tracking-wide text-naranja-500">{e.fecha}</p>
              <h3 className="font-display text-lg uppercase tracking-wide text-tinta-900">{e.titulo}</h3>
              <p className="text-sm text-tinta-500">{e.resumen}</p>
            </div>
          </Tarjeta>
        ))}
      </div>
    </Contenedor>
  )
}
