import { useState } from 'react'
import { useParams, Link, useNavigate } from 'react-router-dom'
import { CheckCircle2, Clock, ShoppingBasket, Home as HomeIcon } from 'lucide-react'
import { useDemo, useNow, STATUS_LABEL, FLOW } from '../store/DemoStore.jsx'
import { describeItem } from '../store/pricing.js'
import { productoPorId } from '../data/catalogo.js'
import { Contenedor } from '../shell/Layout.jsx'
import { Tarjeta, Button, Badge } from '../ui/index.jsx'
import { clockTime, minsUntil, money } from '../lib/format.js'

const TONE_BY_STATUS = {
  recibido: 'bg-tinta-700',
  preparando: 'bg-naranja-500',
  empacado: 'bg-naranja-600',
  listo: 'bg-oliva-600',
  en_camino: 'bg-verde-600',
  entregado: 'bg-oliva-700',
}

export default function OrdenSeguimiento() {
  const { id } = useParams()
  const { state } = useDemo()
  const navigate = useNavigate()
  const [verSello, setVerSello] = useState(true)
  useNow(5000)

  const orden = state.orders.find((o) => o.id === id)
  if (!orden) return <Contenedor className="py-10 text-center text-tinta-500">No encontramos ese pedido.</Contenedor>

  const chain = FLOW[orden.mode]
  const idx = chain.indexOf(orden.status)

  if (verSello) {
    return (
      <Contenedor ancho="angosto">
        <div className="mt-10 flex flex-col items-center gap-4 text-center">
          <div className="grid h-24 w-24 place-items-center rounded-full bg-oliva-500 text-papel-50 animate-stamp">
            <CheckCircle2 size={48} />
          </div>
          <h1 className="font-display text-2xl uppercase tracking-wide text-tinta-900">¡Tu compra fue enviada!</h1>
          <p className="font-display text-3xl text-verde-700">{orden.code}</p>
          <Tarjeta className="flex items-center gap-2 px-5 py-3 text-sm text-tinta-600">
            <Clock size={16} /> Tiempo estimado: ~{minsUntil(orden.eta)} min
          </Tarjeta>
          <div className="mt-4 flex gap-3">
            <Button variant="outline" onClick={() => setVerSello(false)}>Ver mi pedido</Button>
            <Button variant="primary" as={Link} to="/">Volver al inicio</Button>
          </div>
        </div>
      </Contenedor>
    )
  }

  return (
    <Contenedor ancho="angosto">
      <div className={`mt-4 rounded-2xl p-5 text-papel-50 ${TONE_BY_STATUS[orden.status] || 'bg-tinta-700'}`}>
        <p className="text-xs font-bold uppercase tracking-wide opacity-80">{orden.code} · {orden.mode === 'delivery' ? 'Entrega' : 'Recoger en tienda'}</p>
        <h1 className="font-display text-2xl uppercase tracking-wide">{STATUS_LABEL[orden.status]}</h1>
        <div className="mt-3 flex gap-1">
          {chain.map((s, i) => (
            <span key={s} className={`h-1.5 flex-1 rounded-full ${i <= idx ? 'bg-white' : 'bg-white/25'}`} />
          ))}
        </div>
      </div>

      <Tarjeta className="mt-4 p-5">
        <p className="mb-3 text-sm font-semibold text-tinta-700">Línea de tiempo</p>
        <div className="space-y-4">
          {orden.statusHistory.map((h, i) => (
            <div key={i} className="flex gap-3">
              <div className="flex flex-col items-center">
                <span className="grid h-7 w-7 place-items-center rounded-full bg-verde-600 text-papel-50"><CheckCircle2 size={14} /></span>
                {i < orden.statusHistory.length - 1 && <span className="mt-1 h-full w-px flex-1 bg-papel-300" />}
              </div>
              <div className="pb-2">
                <p className="text-sm font-bold text-tinta-800">{STATUS_LABEL[h.status]}</p>
                <p className="text-xs text-tinta-400">{clockTime(h.at)}</p>
              </div>
            </div>
          ))}
        </div>
      </Tarjeta>

      <Tarjeta className="mt-4 p-5">
        <p className="mb-3 text-sm font-semibold text-tinta-700">Tu compra</p>
        <div className="space-y-2">
          {orden.items.map((item, i) => {
            const p = productoPorId(item.productId)
            return (
              <div key={i} className="flex items-center justify-between text-sm">
                <span className="text-tinta-700">{p.nombre} · {describeItem(item).join(', ')}</span>
              </div>
            )
          })}
        </div>
      </Tarjeta>

      <div className="mt-4 flex gap-3">
        <Button variant="outline" className="flex-1" as={Link} to="/mis-ordenes"><ShoppingBasket size={16} /> Mis pedidos</Button>
        <Button variant="primary" className="flex-1" as={Link} to="/"><HomeIcon size={16} /> Inicio</Button>
      </div>
    </Contenedor>
  )
}
