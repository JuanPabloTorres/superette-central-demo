import { useEffect } from 'react'
import { Bell, ShoppingBasket, CheckCircle2, Truck, PackageCheck, Info } from 'lucide-react'
import { useDemo, useNow } from '../store/DemoStore.jsx'
import { Contenedor, PageHeader, SectionHeader } from '../shell/Layout.jsx'
import { Tarjeta, EmptyState, cx } from '../ui/index.jsx'
import { relTime, clockTime, dayLabel } from '../lib/format.js'

const ICONO_POR_KIND = { info: Info, success: CheckCircle2 }

export default function Alertas() {
  const { state, readNotifications } = useDemo()
  useNow(15000)

  useEffect(() => {
    const t = setTimeout(readNotifications, 1400)
    return () => clearTimeout(t)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const notifs = [...state.notifications].sort((a, b) => b.at - a.at)

  return (
    <Contenedor>
      <PageHeader title="Alertas" sub="Así se entera tu cliente de cada paso de su compra, sin llamarte." />

      <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div>
          {notifs.length === 0 ? (
            <EmptyState icon={Bell} title="No tienes avisos todavía." />
          ) : (
            <div className="space-y-2">
              {notifs.map((n) => {
                const Icon = ICONO_POR_KIND[n.kind] || Info
                return (
                  <Tarjeta key={n.id} className={cx('flex items-start gap-3 p-4', !n.read && 'ring-2 ring-naranja-200')}>
                    <div className={cx('grid h-9 w-9 shrink-0 place-items-center rounded-full', n.kind === 'success' ? 'bg-oliva-100 text-oliva-600' : 'bg-verde-100 text-verde-700')}>
                      <Icon size={17} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-bold text-tinta-800">{n.title}</p>
                      <p className="text-sm text-tinta-500">{n.body}</p>
                      <p className="mt-1 text-xs text-tinta-400">{relTime(n.at)}</p>
                    </div>
                  </Tarjeta>
                )
              })}
            </div>
          )}
        </div>

        <div className="hidden lg:block">
          <PantallaBloqueo notifs={notifs.slice(0, 4)} />
        </div>
      </div>

      <SectionHeader title="Cómo se comunica contigo el negocio" />
      <div className="grid gap-3 sm:grid-cols-4">
        <PasoComunicacion n={1} icon={ShoppingBasket} texto="Envías tu pedido desde el portal." />
        <PasoComunicacion n={2} icon={PackageCheck} texto="El negocio lo prepara y lo empaca." />
        <PasoComunicacion n={3} icon={Truck} texto="Te avisa cuando sale o está listo." />
        <PasoComunicacion n={4} icon={CheckCircle2} texto="Confirmas que todo llegó bien." />
      </div>

      <div className="mt-8 rounded-2xl banda-verde px-6 py-8 text-center text-papel-50">
        <p className="font-serif text-lg italic">"Sabes exactamente en qué va tu compra, sin tener que llamar."</p>
      </div>
    </Contenedor>
  )
}

function PantallaBloqueo({ notifs }) {
  const now = useNow(30000)
  return (
    <div className="mx-auto w-64 rounded-[2.5rem] border-8 border-tinta-900 bg-tinta-950 p-3 shadow-2xl">
      <div className="rounded-[1.8rem] papel-oscuro px-4 pb-6 pt-10 text-center text-papel-50">
        <p className="text-4xl font-light">{clockTime(now)}</p>
        <p className="mt-1 text-xs capitalize text-papel-300">{dayLabel(now)}</p>
        <div className="mt-6 space-y-2 text-left">
          {notifs.length === 0 && <p className="text-center text-xs text-papel-400">Sin notificaciones</p>}
          {notifs.map((n) => (
            <div key={n.id} className="rounded-2xl bg-white/10 p-3 backdrop-blur">
              <p className="text-xs font-bold text-white">{n.title}</p>
              <p className="line-clamp-2 text-[11px] text-papel-200">{n.body}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

function PasoComunicacion({ n, icon: Icon, texto }) {
  return (
    <Tarjeta className="flex flex-col items-center gap-2 p-4 text-center">
      <div className="grid h-10 w-10 place-items-center rounded-full bg-verde-100 font-display text-verde-700">{n}</div>
      <Icon size={18} className="text-tinta-400" />
      <p className="text-xs text-tinta-600">{texto}</p>
    </Tarjeta>
  )
}
