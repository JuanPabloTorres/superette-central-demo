import { Link } from 'react-router-dom'
import { Heart, Gift, LogOut, Bell, ShoppingBasket } from 'lucide-react'
import { useDemo } from '../store/DemoStore.jsx'
import { productoPorId } from '../data/catalogo.js'
import { Contenedor, PageHeader, SectionHeader } from '../shell/Layout.jsx'
import { Tarjeta, Switch, Button, EmptyState, Badge } from '../ui/index.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'
import { IconoCirculo } from '../ui/Brand.jsx'
import { money } from '../lib/format.js'

export default function Cuenta() {
  const { state, toggleFavorite } = useDemo()
  const cliente = state.customers.find((c) => c.id === state.account.id)
  const favoritos = state.favorites.map((id) => productoPorId(id)).filter(Boolean)
  const misOrdenes = state.orders.filter((o) => state.myOrderIds.includes(o.id))

  return (
    <Contenedor ancho="angosto">
      <PageHeader title="Mi cuenta" />

      <Tarjeta className="flex items-center gap-4 p-5">
        <IconoCirculo icon={ShoppingBasket} tone="primario" size="lg" />
        <div className="min-w-0 flex-1">
          <p className="font-display text-lg uppercase tracking-wide text-tinta-900">{state.account.name}</p>
          <p className="text-sm text-tinta-500">{state.account.phone}</p>
        </div>
      </Tarjeta>

      <div className="mt-4 grid grid-cols-3 gap-3">
        <Metric label="Pedidos" value={misOrdenes.length} />
        <Metric label="Puntos" value={cliente?.puntos ?? 0} />
        <Metric label="Gastado" value={money(cliente?.totalGastado ?? 0)} />
      </div>

      <Tarjeta className="mt-4 flex items-center justify-between gap-3 p-5">
        <div className="flex items-center gap-3">
          <IconoCirculo icon={Gift} tone="acento" size="sm" />
          <div>
            <p className="font-bold text-tinta-800">Recompensa</p>
            <p className="text-sm text-tinta-500">{cliente?.puntos ?? 0} / {state.settings.rewardGoalPoints} pts para ${state.settings.rewardValue}</p>
          </div>
        </div>
        <Badge tone="amber">{Math.round(((cliente?.puntos ?? 0) / state.settings.rewardGoalPoints) * 100)}%</Badge>
      </Tarjeta>

      <SectionHeader title="Favoritos" />
      {favoritos.length === 0 ? (
        <EmptyState icon={Heart} title="Marca productos como favoritos desde el catálogo." />
      ) : (
        <div className="grid grid-cols-3 gap-3">
          {favoritos.map((p) => (
            <Tarjeta key={p.id} className="relative overflow-hidden">
              <button onClick={() => toggleFavorite(p.id)} className="absolute right-2 top-2 z-10 grid h-7 w-7 place-items-center rounded-full bg-white/90 text-red-500">
                <Heart size={14} fill="currentColor" />
              </button>
              <FoodArt fotoId={p.fotoId} size="tile" className="aspect-square w-full" />
              <p className="line-clamp-2 p-2 text-xs font-semibold text-tinta-700">{p.nombre}</p>
            </Tarjeta>
          ))}
        </div>
      )}

      <SectionHeader title="Preferencias de aviso" />
      <Tarjeta className="space-y-4 p-5">
        <Switch checked label="Avisos de estado de mi pedido" onChange={() => {}} />
        <Switch checked label="Promociones y ofertas semanales" onChange={() => {}} />
        <Switch checked={false} label="Recordatorios de eventos" onChange={() => {}} />
      </Tarjeta>

      <Button variant="ghost" className="mt-6 w-full text-tinta-400">
        <LogOut size={16} /> Cerrar sesión
      </Button>
    </Contenedor>
  )
}

function Metric({ label, value }) {
  return (
    <Tarjeta className="flex flex-col items-center gap-1 py-4">
      <span className="font-display text-xl text-tinta-900">{value}</span>
      <span className="text-[11px] uppercase tracking-wide text-tinta-400">{label}</span>
    </Tarjeta>
  )
}
