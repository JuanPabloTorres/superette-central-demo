import { Link } from 'react-router-dom'
import { Tag } from 'lucide-react'
import { PROMOS } from '../data/promos.js'
import { Contenedor, PageHeader, SectionHeader } from '../shell/Layout.jsx'
import { Tarjeta, Badge, EmptyState, DemoDataNote } from '../ui/index.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'

export default function Promociones() {
  const activas = PROMOS.filter((p) => p.activa)
  const pausadas = PROMOS.filter((p) => !p.activa)
  const destacada = activas.find((p) => p.destacada)
  const resto = activas.filter((p) => p !== destacada)

  return (
    <Contenedor>
      <PageHeader title="Promociones" sub="Ofertas de la semana para ahorrar más en tu compra." />

      {destacada && (
        <Tarjeta as={Link} to={`/promo/${destacada.slug}`} hover className="relative flex min-w-0 flex-col overflow-hidden sm:flex-row">
          <FoodArt fotoId={destacada.fotoId} size="banner" className="h-48 w-full sm:h-auto sm:w-72" />
          <div className="flex flex-1 flex-col justify-center gap-2 p-6">
            <Badge tone="amber">Destacada</Badge>
            <h2 className="font-display text-2xl uppercase tracking-wide text-tinta-900">{destacada.titulo}</h2>
            <p className="text-sm text-tinta-500">{destacada.descripcion}</p>
          </div>
        </Tarjeta>
      )}

      <SectionHeader title="Más ofertas activas" />
      {resto.length === 0 ? (
        <EmptyState icon={Tag} title="No hay más promociones activas por ahora." />
      ) : (
        <div className="grid gap-3 lg:grid-cols-2">
          {resto.map((p) => <FilaPromo key={p.id} promo={p} />)}
        </div>
      )}

      <SectionHeader title="Pausadas" sub="Vuelven pronto." />
      {pausadas.length === 0 ? (
        <EmptyState icon={Tag} title="No hay promociones pausadas." />
      ) : (
        <div className="grid gap-3 opacity-60 lg:grid-cols-2">
          {pausadas.map((p) => <FilaPromo key={p.id} promo={p} pausada />)}
        </div>
      )}

      <DemoDataNote />
    </Contenedor>
  )
}

function FilaPromo({ promo, pausada }) {
  return (
    <Tarjeta as={pausada ? 'div' : Link} to={pausada ? undefined : `/promo/${promo.slug}`} hover={!pausada} className="flex min-w-0 gap-3 p-3">
      <FoodArt fotoId={promo.fotoId} size="thumb" className="h-20 w-20 shrink-0 rounded-xl" />
      <div className="min-w-0 flex-1">
        <p className="truncate font-bold text-tinta-800">{promo.titulo}</p>
        <p className="line-clamp-2 text-sm text-tinta-500">{promo.resumen}</p>
        {pausada && <Badge tone="neutral" className="mt-1">Pausada</Badge>}
      </div>
    </Tarjeta>
  )
}
