import { Link, useNavigate } from 'react-router-dom'
import { Minus, Plus, Trash2, ShoppingBasket, Tag, Gift } from 'lucide-react'
import { useDemo, useCartTotals } from '../store/DemoStore.jsx'
import { describeItem, lineTotal, unitPrice } from '../store/pricing.js'
import { productoPorId } from '../data/catalogo.js'
import { promoActiva } from '../data/promos.js'
import { Contenedor, PageHeader } from '../shell/Layout.jsx'
import { Tarjeta, Button, EmptyState, Switch, Badge } from '../ui/index.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'
import { money } from '../lib/format.js'

export default function Carrito() {
  const { state, setQty, removeItem, applyPromo, setReward } = useDemo()
  const navigate = useNavigate()
  const totals = useCartTotals('pickup')
  const cliente = state.customers.find((c) => c.id === state.account.id)
  const promosDisponibles = promoActiva()

  if (state.cart.length === 0) {
    return (
      <Contenedor>
        <PageHeader title="Tu carrito" />
        <EmptyState
          icon={ShoppingBasket}
          title="Tu carrito está vacío todavía."
          action={<Button as={Link} to="/catalogo" variant="primary">Empezar mi compra</Button>}
        />
      </Contenedor>
    )
  }

  return (
    <Contenedor ancho="angosto">
      <PageHeader title="Tu carrito" sub={`${state.cart.length} producto${state.cart.length > 1 ? 's' : ''} en tu compra`} />

      <div className="space-y-3">
        {state.cart.map((item, i) => {
          const producto = productoPorId(item.productId)
          const desc = describeItem(item)
          return (
            <Tarjeta key={i} className="flex min-w-0 gap-3 p-3">
              <FoodArt fotoId={producto.fotoId} size="thumb" className="h-20 w-20 shrink-0 rounded-xl" />
              <div className="flex min-w-0 flex-1 flex-col justify-between">
                <div>
                  <p className="truncate font-bold text-tinta-800">{producto.nombre}</p>
                  <p className="text-xs text-tinta-400">{desc.join(' · ')}</p>
                </div>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <button
                      aria-label="Reducir"
                      onClick={() => setQty(i, +(item.cantidad - (producto.unidad === 'lb' ? 0.5 : 1)).toFixed(2))}
                      className="grid h-8 w-8 place-items-center rounded-full border border-papel-300 text-tinta-600 hover:border-verde-400"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="w-10 text-center text-sm font-bold text-tinta-800">{item.cantidad}</span>
                    <button
                      aria-label="Aumentar"
                      onClick={() => setQty(i, +(item.cantidad + (producto.unidad === 'lb' ? 0.5 : 1)).toFixed(2))}
                      className="grid h-8 w-8 place-items-center rounded-full border border-papel-300 text-tinta-600 hover:border-verde-400"
                    >
                      <Plus size={14} />
                    </button>
                  </div>
                  <span className="font-bold text-verde-700">{money(lineTotal(item, state.prices))}</span>
                </div>
              </div>
              <button aria-label="Eliminar" onClick={() => removeItem(i)} className="self-start text-tinta-300 hover:text-red-500">
                <Trash2 size={16} />
              </button>
            </Tarjeta>
          )
        })}
      </div>

      <Tarjeta className="mt-6 space-y-3 p-4">
        <p className="flex items-center gap-2 text-sm font-semibold text-tinta-700"><Tag size={16} /> Código de promoción</p>
        <div className="flex flex-wrap gap-2">
          {promosDisponibles.map((p) => (
            <button
              key={p.id}
              onClick={() => applyPromo(state.promoId === p.id ? null : p.id)}
              className={`rounded-full border px-3 py-1.5 text-xs font-bold ${state.promoId === p.id ? 'border-verde-600 bg-verde-600 text-papel-50' : 'border-papel-300 text-tinta-600'}`}
            >
              {p.titulo}
            </button>
          ))}
        </div>
      </Tarjeta>

      {cliente && cliente.puntos > 0 && (
        <Tarjeta className="mt-3 flex items-center justify-between gap-3 p-4">
          <span className="flex items-center gap-2 text-sm font-semibold text-tinta-700">
            <Gift size={16} /> Canjear {cliente.puntos} pts (hasta ${state.settings.rewardValue})
          </span>
          <Switch checked={state.rewardRedeem} onChange={setReward} />
        </Tarjeta>
      )}

      <Tarjeta className="mt-4 space-y-2 p-5">
        <Fila label="Subtotal" value={money(totals.subtotal)} />
        {totals.discount > 0 && <Fila label="Descuento" value={`-${money(totals.discount)}`} tone="text-oliva-600" />}
        <Fila label="Impuesto (IVU 11.5%)" value={money(totals.tax)} />
        <p className="text-xs text-tinta-400">El cargo de entrega se calcula en el siguiente paso si eliges entrega a domicilio.</p>
        <div className="my-1 h-px bg-papel-200" />
        <Fila label="Total estimado" value={money(totals.subtotal - totals.discount + totals.tax)} big />
        {totals.points > 0 && <Badge tone="amber">Ganas {totals.points} pts en esta compra</Badge>}
      </Tarjeta>

      <Button variant="primary" size="lg" className="mt-4 w-full" onClick={() => navigate('/checkout')}>
        Continuar
      </Button>
    </Contenedor>
  )
}

function Fila({ label, value, tone = 'text-tinta-700', big }) {
  return (
    <div className="flex items-center justify-between">
      <span className={big ? 'font-display uppercase tracking-wide text-tinta-900' : 'text-sm text-tinta-500'}>{label}</span>
      <span className={big ? `font-display text-xl ${tone}` : `text-sm font-semibold ${tone}`}>{value}</span>
    </div>
  )
}
