import { useParams, useNavigate, Link } from 'react-router-dom'
import { ArrowLeft, CheckCircle2 } from 'lucide-react'
import { promoPorSlug } from '../data/promos.js'
import { useDemo } from '../store/DemoStore.jsx'
import { Contenedor } from '../shell/Layout.jsx'
import { Tarjeta, Button, Badge, DemoDataNote } from '../ui/index.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'

export default function PromoDetalle() {
  const { slug } = useParams()
  const promo = promoPorSlug(slug)
  const navigate = useNavigate()
  const { applyPromo, toast } = useDemo()

  if (!promo) return <Contenedor className="py-10 text-center text-tinta-500">No encontramos esa promoción.</Contenedor>

  return (
    <Contenedor ancho="angosto">
      <button onClick={() => navigate('/promociones')} className="mt-5 flex items-center gap-1 text-sm font-semibold text-tinta-500 hover:text-verde-700">
        <ArrowLeft size={16} /> Volver a promociones
      </button>

      <Tarjeta className="mt-4 overflow-hidden">
        <FoodArt fotoId={promo.fotoId} size="banner" className="h-56 w-full" />
        <div className="space-y-4 p-6">
          <div className="flex items-center gap-2">
            {promo.destacada && <Badge tone="amber">Destacada</Badge>}
            <Badge tone={promo.activa ? 'green' : 'neutral'}>{promo.activa ? 'Activa' : 'Pausada'}</Badge>
          </div>
          <h1 className="font-display text-2xl uppercase tracking-wide text-tinta-900">{promo.titulo}</h1>
          <p className="text-2xl font-bold text-verde-700">
            {promo.tipo === 'percent' ? `${promo.valor}% de descuento` : `$${promo.valor.toFixed(2)} de descuento`}
          </p>
          <p className="text-sm text-tinta-600">{promo.descripcion}</p>

          <div>
            <p className="mb-2 text-sm font-semibold text-tinta-700">Qué incluye</p>
            <ul className="space-y-1.5 text-sm text-tinta-600">
              <li className="flex items-center gap-2"><CheckCircle2 size={15} className="text-oliva-500" /> Aplica en las categorías de la promoción</li>
              <li className="flex items-center gap-2"><CheckCircle2 size={15} className="text-oliva-500" /> Compra mínima de ${promo.minimo.toFixed(2)}</li>
              <li className="flex items-center gap-2"><CheckCircle2 size={15} className="text-oliva-500" /> Se aplica automáticamente en el carrito</li>
            </ul>
          </div>

          <div className="rounded-xl bg-papel-100 p-4 text-xs text-tinta-500">{promo.terminos}</div>

          <Button
            variant="primary"
            size="lg"
            className="w-full"
            disabled={!promo.activa}
            onClick={() => { applyPromo(promo.id); toast('Promoción aplicada a tu compra', 'success'); navigate('/catalogo') }}
          >
            {promo.activa ? 'Usar esta promoción' : 'No disponible ahora'}
          </Button>
        </div>
      </Tarjeta>
      <DemoDataNote />
    </Contenedor>
  )
}
