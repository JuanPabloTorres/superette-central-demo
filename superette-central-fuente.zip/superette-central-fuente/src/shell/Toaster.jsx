import { useEffect } from 'react'
import { CheckCircle2, Info, X } from 'lucide-react'
import { useDemo } from '../store/DemoStore.jsx'
import { cx } from '../ui/index.jsx'

export function Toaster() {
  const { state, dismissToast } = useDemo()
  return (
    <div className="pointer-events-none fixed inset-x-0 top-[64px] z-[90] flex flex-col items-center gap-2 px-4">
      {state.toasts.slice(-3).map((t) => (
        <Toast key={t.id} toast={t} onDone={() => dismissToast(t.id)} />
      ))}
    </div>
  )
}

function Toast({ toast, onDone }) {
  useEffect(() => {
    const id = setTimeout(onDone, 3600)
    return () => clearTimeout(id)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])
  const Icon = toast.tone === 'success' ? CheckCircle2 : Info
  const tone = toast.tone === 'success' ? 'text-oliva-600' : 'text-verde-600'
  return (
    <div className="pointer-events-auto flex w-full max-w-sm animate-drop items-center gap-2.5 rounded-2xl border border-papel-300 bg-white px-4 py-3 shadow-lg">
      <Icon size={18} className={cx('shrink-0', tone)} />
      <p className="min-w-0 flex-1 truncate text-sm font-semibold text-tinta-800">{toast.message}</p>
      <button aria-label="Cerrar aviso" onClick={onDone} className="shrink-0 text-tinta-400 hover:text-tinta-600">
        <X size={14} />
      </button>
    </div>
  )
}
