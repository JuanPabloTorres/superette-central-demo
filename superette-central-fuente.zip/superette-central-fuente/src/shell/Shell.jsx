import { useEffect, useState } from 'react'
import { Routes, Route, Navigate, Link, useLocation, useNavigate } from 'react-router-dom'
import { AlertTriangle, RefreshCcw, HelpCircle, ShoppingBasket, Home, Grid2x2, Bell, User, Store, ChevronRight } from 'lucide-react'
import { useDemo, useCartCount, useCartTotals } from '../store/DemoStore.jsx'
import { Contenedor } from './Layout.jsx'
import { Segmented, Badge, Button, cx } from '../ui/index.jsx'
import { Wordmark } from '../ui/Brand.jsx'
import { Toaster } from './Toaster.jsx'
import { Guide } from './Guide.jsx'
import { BUSINESS } from '../data/config.js'
import { money } from '../lib/format.js'

import Home_ from '../customer/Home.jsx'
import Catalogo from '../customer/Catalogo.jsx'
import Promociones from '../customer/Promociones.jsx'
import PromoDetalle from '../customer/PromoDetalle.jsx'
import Carrito from '../customer/Carrito.jsx'
import Checkout from '../customer/Checkout.jsx'
import OrdenSeguimiento from '../customer/OrdenSeguimiento.jsx'
import MisOrdenes from '../customer/MisOrdenes.jsx'
import Alertas from '../customer/Alertas.jsx'
import Cuenta from '../customer/Cuenta.jsx'
import Eventos from '../customer/Eventos.jsx'

import NegocioResumen from '../negocio/Resumen.jsx'
import NegocioEmpaque from '../negocio/Empaque.jsx'
import NegocioCatalogo from '../negocio/CatalogoAdmin.jsx'
import NegocioPromociones from '../negocio/PromocionesAdmin.jsx'
import NegocioClientes from '../negocio/Clientes.jsx'
import NegocioCanales from '../negocio/Canales.jsx'
import NegocioConfig from '../negocio/Config.jsx'

export function Shell() {
  const { state, reset } = useDemo()
  const location = useLocation()
  const navigate = useNavigate()
  const [guideOpen, setGuideOpen] = useState(false)
  const cartCount = useCartCount()
  const totals = useCartTotals()
  const modoNegocio = location.pathname.startsWith('/negocio')
  const ocultarBarraCarrito = ['/carrito', '/checkout'].includes(location.pathname) || location.pathname.startsWith('/orden')
  const mostrarBarraCarrito = !modoNegocio && !ocultarBarraCarrito && cartCount > 0

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' in window ? 'instant' : 'auto' })
  }, [location.pathname])

  return (
    <div className={cx('min-h-screen papel pb-16 lg:pb-0', mostrarBarraCarrito && 'pb-36 lg:pb-24')}>
      {/* Barra de demo */}
      <div className="sticky top-0 z-50 flex h-11 items-center justify-between gap-3 bg-tinta-900 px-3 text-papel-100 sm:px-5">
        <div className="flex min-w-0 items-center gap-2 text-[11px] sm:text-xs">
          <AlertTriangle size={14} className="shrink-0 text-naranja-300" />
          <span className="truncate">Demostración — datos simulados</span>
        </div>
        <div className="flex shrink-0 items-center gap-2">
          <button onClick={() => setGuideOpen(true)} className="flex items-center gap-1 text-[11px] font-semibold text-papel-200 hover:text-white sm:text-xs">
            <HelpCircle size={14} /> <span className="hidden sm:inline">Guía</span>
          </button>
          <button onClick={reset} className="flex items-center gap-1 text-[11px] font-semibold text-papel-200 hover:text-white sm:text-xs">
            <RefreshCcw size={14} /> <span className="hidden sm:inline">Reiniciar</span>
          </button>
          <Segmented
            tone="dark"
            value={modoNegocio ? 'negocio' : 'cliente'}
            onChange={(v) => navigate(v === 'negocio' ? '/negocio' : '/')}
            options={[{ value: 'cliente', label: 'Cliente', icon: User }, { value: 'negocio', label: 'Negocio', icon: Store }]}
          />
        </div>
      </div>

      {/* Cabecera del portal */}
      <div className="sticky top-11 z-40 border-b border-papel-300 bg-white/95 elev-1 backdrop-blur">
        <Contenedor className="flex h-[70px] items-center justify-between gap-4">
          <Link to={modoNegocio ? '/negocio' : '/'} className="flex items-center gap-2">
            <Wordmark />
          </Link>
          {!modoNegocio && (
            <nav className="hidden h-full items-stretch gap-6 text-sm font-semibold text-tinta-600 lg:flex">
              <NavLink to="/" active={location.pathname === '/'}>Inicio</NavLink>
              <NavLink to="/catalogo" active={location.pathname === '/catalogo'}>Compra</NavLink>
              <NavLink to="/promociones" active={location.pathname.startsWith('/promo')}>Promociones</NavLink>
              <NavLink to="/eventos" active={location.pathname === '/eventos'}>Eventos</NavLink>
            </nav>
          )}
          {modoNegocio && (
            <nav className="hidden h-full items-stretch gap-6 text-sm font-semibold text-tinta-600 lg:flex">
              <NavLink to="/negocio" active={location.pathname === '/negocio'}>Resumen</NavLink>
              <NavLink to="/negocio/empaque" active={location.pathname === '/negocio/empaque'}>Operación</NavLink>
              <NavLink to="/negocio/catalogo" active={location.pathname === '/negocio/catalogo'}>Catálogo</NavLink>
              <NavLink to="/negocio/promociones" active={location.pathname === '/negocio/promociones'}>Promociones</NavLink>
              <NavLink to="/negocio/clientes" active={location.pathname === '/negocio/clientes'}>Clientes</NavLink>
              <NavLink to="/negocio/canales" active={location.pathname === '/negocio/canales'}>Canales</NavLink>
            </nav>
          )}
          <div className="flex items-center gap-3">
            {!modoNegocio ? (
              <Link to="/carrito" aria-label="Carrito" className="relative grid h-10 w-10 place-items-center rounded-full text-tinta-700 transition-colors hover:bg-papel-200">
                <ShoppingBasket size={20} />
                {cartCount > 0 && (
                  <Badge tone="amber" className="absolute -right-1 -top-1 h-5 min-w-5 justify-center px-1">{cartCount}</Badge>
                )}
              </Link>
            ) : (
              <Link to="/negocio/config" aria-label="Configuración" className="grid h-10 w-10 place-items-center rounded-full text-tinta-700 transition-colors hover:bg-papel-200">
                <Store size={20} />
              </Link>
            )}
          </div>
        </Contenedor>
      </div>

      <main>
        <Routes>
          <Route path="/" element={<Home_ />} />
          <Route path="/catalogo" element={<Catalogo />} />
          <Route path="/promociones" element={<Promociones />} />
          <Route path="/promo/:slug" element={<PromoDetalle />} />
          <Route path="/carrito" element={<Carrito />} />
          <Route path="/checkout" element={<Checkout />} />
          <Route path="/orden/:id" element={<OrdenSeguimiento />} />
          <Route path="/mis-ordenes" element={<MisOrdenes />} />
          <Route path="/alertas" element={<Alertas />} />
          <Route path="/cuenta" element={<Cuenta />} />
          <Route path="/eventos" element={<Eventos />} />

          <Route path="/negocio" element={<NegocioResumen />} />
          <Route path="/negocio/empaque" element={<NegocioEmpaque />} />
          <Route path="/negocio/catalogo" element={<NegocioCatalogo />} />
          <Route path="/negocio/promociones" element={<NegocioPromociones />} />
          <Route path="/negocio/clientes" element={<NegocioClientes />} />
          <Route path="/negocio/canales" element={<NegocioCanales />} />
          <Route path="/negocio/config" element={<NegocioConfig />} />

          {/* Redirecciones de rutas antiguas */}
          <Route path="/menu" element={<Navigate to="/catalogo" replace />} />
          <Route path="/negocio/menu" element={<Navigate to="/negocio/catalogo" replace />} />
          <Route path="/servicios" element={<Navigate to="/catalogo" replace />} />
          <Route path="/negocio/cocina" element={<Navigate to="/negocio/empaque" replace />} />
          <Route path="/negocio/agenda" element={<Navigate to="/negocio/empaque" replace />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <footer className="mt-16 border-t border-papel-300 bg-white py-10">
        <Contenedor className="flex flex-col items-center gap-2 text-center">
          <Wordmark size="sm" />
          <p className="font-serif text-base italic text-tinta-500">Tu compra de siempre, con menos filas y más tiempo para ti.</p>
          <p className="text-xs text-tinta-400">{BUSINESS.town} · {BUSINESS.phone}</p>
        </Contenedor>
      </footer>

      {mostrarBarraCarrito && (
        <div className={cx('fixed inset-x-0 z-40 flex justify-center px-4', 'bottom-20 lg:bottom-5')}>
          <Link
            to="/carrito"
            className="flex w-full max-w-md items-center gap-3 rounded-2xl bg-tinta-900 px-4 py-3.5 text-papel-50 elev-4 transition-transform active:scale-[.98]"
          >
            <span className="relative grid h-9 w-9 shrink-0 place-items-center rounded-full bg-verde-600">
              <ShoppingBasket size={17} />
              <Badge tone="amber" className="absolute -right-1.5 -top-1.5 h-5 min-w-5 justify-center px-1 text-[10px]">{cartCount}</Badge>
            </span>
            <span className="min-w-0 flex-1 text-sm font-bold">Ver carrito · {money(totals.total)}</span>
            <ChevronRight size={18} className="shrink-0" />
          </Link>
        </div>
      )}

      {!modoNegocio && (
        <nav className="fixed inset-x-0 bottom-0 z-50 flex h-16 items-stretch border-t border-papel-300 bg-white lg:hidden">
          <BottomLink to="/" icon={Home} label="Inicio" active={location.pathname === '/'} />
          <BottomLink to="/catalogo" icon={Grid2x2} label="Compra" active={location.pathname === '/catalogo'} />
          <BottomLink to="/carrito" icon={ShoppingBasket} label="Carrito" active={location.pathname === '/carrito'} badge={cartCount} />
          <BottomLink to="/alertas" icon={Bell} label="Alertas" active={location.pathname === '/alertas'} badge={state.notifications.filter((n) => !n.read).length} />
          <BottomLink to="/cuenta" icon={User} label="Cuenta" active={location.pathname === '/cuenta'} />
        </nav>
      )}

      <Toaster />
      <Guide open={guideOpen} onClose={() => setGuideOpen(false)} />
    </div>
  )
}

function BottomLink({ to, icon: Icon, label, active, badge }) {
  return (
    <Link to={to} className={cx('relative flex flex-1 flex-col items-center justify-center gap-0.5 text-[11px] font-semibold transition-colors', active ? 'text-verde-700' : 'text-tinta-400 hover:text-tinta-600')}>
      <span className="relative">
        <Icon size={20} strokeWidth={active ? 2.4 : 2} />
        {badge > 0 && <Badge tone="amber" className="absolute -right-3 -top-1.5 h-4 min-w-4 justify-center px-1 text-[9px]">{badge}</Badge>}
      </span>
      {label}
      {active && <span className="absolute top-0 h-0.5 w-6 rounded-full bg-verde-600" />}
    </Link>
  )
}

function NavLink({ to, active, children }) {
  return (
    <Link
      to={to}
      className={cx(
        'flex items-center border-b-2 border-transparent transition-colors hover:text-verde-600',
        active && 'border-verde-600 text-verde-700'
      )}
    >
      {children}
    </Link>
  )
}
