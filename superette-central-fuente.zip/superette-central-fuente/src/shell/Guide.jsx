import { Link } from 'react-router-dom'
import { Megaphone, ShoppingBasket, ClipboardList, BellRing, LayoutDashboard } from 'lucide-react'
import { Modal, SheetHeader, Button } from '../ui/index.jsx'

const PASOS = [
  { icon: Megaphone, titulo: 'Negocio → Canales', texto: 'De dónde ya viene la gente: la publicación de redes y el QR. Toca el enlace de la publicación.' },
  { icon: ShoppingBasket, titulo: 'Cliente', texto: 'Agrega una promoción o producto, personalízalo, confirma. Termina en la pantalla de confirmación con el número de pedido.' },
  { icon: ClipboardList, titulo: 'Negocio → Operación', texto: 'El pedido aparece marcado como nuevo en Empaque. Avánzalo dos pasos.' },
  { icon: BellRing, titulo: 'Cliente → Alertas', texto: 'Los avisos ya cambiaron solos y se ven en la pantalla de bloqueo. Este es el momento que vende.' },
  { icon: LayoutDashboard, titulo: 'Negocio → Resumen', texto: 'Trabajo del día, pedidos por confirmar, ventas. Cierra apagando un agotado y copiando el enlace de una promoción.' },
]

export function Guide({ open, onClose }) {
  return (
    <Modal open={open} onClose={onClose} size="lg">
      <SheetHeader id="guia-titulo" title="Guía del recorrido" subtitle="Cinco pasos para presentar el sistema en cinco minutos." onClose={onClose} />
      <div className="space-y-4 px-5 py-5">
        {PASOS.map((p, i) => (
          <div key={i} className="flex gap-3">
            <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-verde-100 font-display text-verde-700">{i + 1}</div>
            <div>
              <p className="font-display uppercase tracking-wide text-tinta-900">{p.titulo}</p>
              <p className="text-sm text-tinta-500">{p.texto}</p>
            </div>
          </div>
        ))}
      </div>
      <div className="flex justify-end gap-2 border-t border-papel-200 px-5 py-4">
        <Button as={Link} to="/negocio/canales" variant="outline" onClick={onClose}>Empezar en Canales</Button>
        <Button variant="primary" onClick={onClose}>Entendido</Button>
      </div>
    </Modal>
  )
}
