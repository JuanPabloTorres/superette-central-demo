import { cx } from '../ui/index.jsx'

const ANCHOS = { angosto: 'max-w-[820px]', normal: 'max-w-[1180px]', ancho: 'max-w-[1400px]' }

export function Contenedor({ ancho = 'normal', className = '', children }) {
  return <div className={cx('mx-auto w-full px-4 sm:px-6', ANCHOS[ancho], className)}>{children}</div>
}

export function PageHeader({ title, sub, right }) {
  return (
    <div className="mb-5 mt-6 flex flex-col gap-3 sm:flex-row sm:items-end sm:justify-between">
      <div>
        <h1 className="font-display text-2xl uppercase tracking-wide text-tinta-900 sm:text-3xl">{title}</h1>
        {sub && <p className="mt-1 text-sm text-tinta-500">{sub}</p>}
      </div>
      {right && <div className="shrink-0">{right}</div>}
    </div>
  )
}

export function SectionHeader({ title, sub, action }) {
  return (
    <div className="mb-3 mt-8 flex items-end justify-between gap-3">
      <div>
        <h2 className="font-display text-lg uppercase tracking-wide text-tinta-900">{title}</h2>
        {sub && <p className="text-sm text-tinta-500">{sub}</p>}
      </div>
      {action}
    </div>
  )
}
