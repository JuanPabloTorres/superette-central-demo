import { ShoppingBasket } from 'lucide-react'
import { cx } from './index.jsx'
import { BUSINESS } from '../data/config.js'

export function Wordmark({ className = '', size = 'md' }) {
  const sizes = { sm: 'text-sm gap-1.5', md: 'text-lg gap-2', lg: 'text-2xl gap-2.5' }
  const badgeSizes = { sm: 'h-6 w-6', md: 'h-9 w-9', lg: 'h-12 w-12' }
  const iconSizes = { sm: 13, md: 18, lg: 24 }
  return (
    <span className={cx('inline-flex items-center leading-none', sizes[size], className)}>
      <span className={cx('grid shrink-0 place-items-center rounded-xl bg-verde-600 text-papel-50 shadow-sm', badgeSizes[size])}>
        <ShoppingBasket size={iconSizes[size]} strokeWidth={2.4} />
      </span>
      <span className="font-display uppercase tracking-tight text-tinta-900">{BUSINESS.name}</span>
    </span>
  )
}

const TONES = {
  primario: 'bg-verde-600 text-papel-50',
  exito: 'bg-oliva-500 text-papel-50',
  acento: 'bg-naranja-500 text-papel-50',
  tinta: 'bg-tinta-800 text-papel-100',
  crema: 'bg-papel-200 text-tinta-700',
}

const SIZES = { sm: 'h-8 w-8', md: 'h-11 w-11', lg: 'h-14 w-14' }

export function IconoCirculo({ icon: Icon, tone = 'primario', size = 'md', className = '' }) {
  const iconSize = size === 'sm' ? 15 : size === 'lg' ? 26 : 20
  return (
    <div className={cx('grid shrink-0 place-items-center rounded-full shadow-sm', TONES[tone], SIZES[size], className)}>
      <Icon size={iconSize} />
    </div>
  )
}

export function DivisorOrnamentado({ className = '' }) {
  return (
    <div className={cx('flex items-center gap-3', className)}>
      <span className="divisor-dorado flex-1" />
      <OrnamentoCanasta className="h-4 w-4 text-naranja-400" />
      <span className="divisor-dorado flex-1" />
    </div>
  )
}

export function OrnamentoCanasta({ className = '' }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} xmlns="http://www.w3.org/2000/svg">
      <path d="M4 10h16l-1.6 9.2a2 2 0 0 1-2 1.8H7.6a2 2 0 0 1-2-1.8L4 10Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
      <path d="M8 10 9.5 4M16 10 14.5 4M9 14v4M12 14v4M15 14v4" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  )
}

export function OrnamentoHoja({ className = '' }) {
  return (
    <svg viewBox="0 0 24 24" fill="none" className={className} xmlns="http://www.w3.org/2000/svg">
      <path d="M4 20c8-1 14-7 15-15-8 1-14 7-15 15Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
      <path d="M6 18c4-2 8-6 10-11" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" />
    </svg>
  )
}

export function IconInstagram({ size = 18, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} xmlns="http://www.w3.org/2000/svg">
      <rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" strokeWidth="1.7" />
      <circle cx="12" cy="12" r="4.2" stroke="currentColor" strokeWidth="1.7" />
      <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" />
    </svg>
  )
}

export function IconFacebook({ size = 18, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} xmlns="http://www.w3.org/2000/svg">
      <circle cx="12" cy="12" r="9.2" stroke="currentColor" strokeWidth="1.7" />
      <path d="M13.6 21v-6.6h2.2l.3-2.6h-2.5V10c0-.75.2-1.26 1.28-1.26H16V6.4c-.23-.03-1-.1-1.9-.1-1.9 0-3.2 1.16-3.2 3.3v1.84H8.7v2.6h2.2V21" stroke="currentColor" strokeWidth="1.4" strokeLinejoin="round" />
    </svg>
  )
}

export function IconWhatsApp({ size = 18, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none" className={className} xmlns="http://www.w3.org/2000/svg">
      <path d="M6 19.5 7 16a7.6 7.6 0 1 1 3 2.7L6 19.5Z" stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
      <path d="M9 10.3c0 3 2.7 5.6 5.6 5.6.9 0 1-.5.9-1.1l-.2-1-1.7-.4-.8 1c-1-.5-2-1.5-2.5-2.5l1-.8-.4-1.7-1-.2c-.5 0-1.1.1-1.1.9Z" fill="currentColor" />
    </svg>
  )
}
