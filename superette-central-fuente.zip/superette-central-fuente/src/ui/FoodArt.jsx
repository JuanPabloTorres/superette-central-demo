import { useState } from 'react'
import { urlFoto } from '../data/fotos.js'
import { cx } from './index.jsx'

export function FoodArt({ id, fotoId, size = 'tile', alt = '', className = '' }) {
  const photoId = id || fotoId
  const [failed, setFailed] = useState(false)
  const url = urlFoto(photoId, size)

  return (
    <div className={cx('relative min-w-0 overflow-hidden bg-papel-200', className)}>
      {!failed && url ? (
        <img
          src={url}
          alt={alt}
          loading="lazy"
          onError={() => setFailed(true)}
          className="absolute inset-0 h-full w-full object-cover"
        />
      ) : (
        <IlustracionRespaldo className="absolute inset-0 h-full w-full" />
      )}
    </div>
  )
}

function IlustracionRespaldo({ className = '' }) {
  return (
    <svg viewBox="0 0 100 100" className={cx('text-papel-400', className)} xmlns="http://www.w3.org/2000/svg">
      <rect width="100" height="100" fill="var(--color-papel-100)" />
      <g transform="translate(50 52) scale(.82) translate(-50 -50)" stroke="currentColor" strokeWidth="2.2" fill="none" strokeLinejoin="round">
        <path d="M28 34h44l-4 42a5 5 0 0 1-5 4.6H37a5 5 0 0 1-5-4.6L28 34Z" />
        <path d="M38 34c0-9 4.5-16 12-16s12 7 12 16" />
        <path d="M40 50v18M50 50v18M60 50v18" strokeLinecap="round" />
      </g>
    </svg>
  )
}
