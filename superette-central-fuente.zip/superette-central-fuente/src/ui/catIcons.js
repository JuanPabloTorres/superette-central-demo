import {
  Package, Beef, Milk, Snowflake, Croissant, Apple, Scale, CupSoda, Cookie,
  SprayCan, Sparkles, Wrench, PawPrint, Baby, Pill, Beer, ShoppingBasket,
} from 'lucide-react'

export const CAT_ICONS = { Package, Beef, Milk, Snowflake, Croissant, Apple, Scale, CupSoda, Cookie, SprayCan, Sparkles, Wrench, PawPrint, Baby, Pill, Beer }
export const CAT_TONES = ['primario', 'exito', 'acento', 'tinta']

export function iconFor(categoria) {
  return CAT_ICONS[categoria?.icon] || ShoppingBasket
}
