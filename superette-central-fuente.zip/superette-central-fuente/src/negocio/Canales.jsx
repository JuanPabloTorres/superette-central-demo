import { useEffect, useState } from 'react'
import QRCode from 'qrcode'
import { Link } from 'react-router-dom'
import { Heart, MessageCircle, Send, Bookmark, Star, MapPin, ExternalLink } from 'lucide-react'
import { PROMOS } from '../data/promos.js'
import { Contenedor, PageHeader } from '../shell/Layout.jsx'
import { Tarjeta, Button } from '../ui/index.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'
import { IconInstagram } from '../ui/Brand.jsx'
import { BUSINESS } from '../data/config.js'

const PASOS = [
  'El cliente ve la publicación en Instagram o el QR en la caja registradora.',
  'Toca el enlace y abre el portal — ya está logueado, sin pasos extra.',
  'Ve la promoción y agrega productos a su compra.',
  'Confirma su pedido en menos de un minuto.',
  'Recibe avisos automáticos de cada paso.',
  'Recoge o recibe su compra y gana puntos.',
]

export default function NegocioCanales() {
  const promo = PROMOS.find((p) => p.destacada) || PROMOS[0]
  const [qr, setQr] = useState(null)
  const url = typeof window !== 'undefined' ? `${window.location.origin}${window.location.pathname}#/promo/${promo.slug}` : ''

  useEffect(() => {
    QRCode.toDataURL(url, { margin: 1, width: 240, color: { dark: '#1e211c', light: '#fdfbf6' } })
      .then(setQr)
      .catch(() => setQr(null))
  }, [url])

  return (
    <Contenedor>
      <PageHeader title="Canales" sub="De dónde ya viene tu gente — y cómo el portal se suma como un canal más." />

      <div className="grid gap-6 lg:grid-cols-2">
        <div>
          <h2 className="mb-3 font-display uppercase tracking-wide text-tinta-900">Publicación de Instagram</h2>
          <Tarjeta className="mx-auto max-w-sm overflow-hidden">
            <div className="flex items-center gap-2 p-3">
              <div className="grid h-8 w-8 place-items-center rounded-full bg-verde-600 text-xs font-bold text-papel-50">SC</div>
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-bold text-tinta-800">{BUSINESS.instagram}</p>
                <p className="flex items-center gap-1 text-[11px] text-tinta-400"><MapPin size={10} /> {BUSINESS.town}</p>
              </div>
            </div>
            <div className="relative">
              <FoodArt fotoId={promo.fotoId} size="card" className="aspect-square w-full" />
              <div className="absolute inset-x-3 bottom-3 rounded-xl bg-black/55 px-3 py-2 text-white backdrop-blur">
                <p className="text-sm font-bold">{promo.titulo}</p>
              </div>
            </div>
            <div className="flex items-center gap-4 px-3 pt-3 text-tinta-700">
              <Heart size={20} /> <MessageCircle size={20} /> <Send size={20} /> <span className="flex-1" /> <Bookmark size={20} />
            </div>
            <div className="space-y-1 px-3 pb-3 pt-2 text-sm text-tinta-700">
              <p><span className="font-bold">{BUSINESS.instagram}</span> {promo.resumen} 🛒</p>
              <Link to={`/promo/${promo.slug}`} className="inline-flex items-center gap-1 text-xs font-bold text-verde-700">
                Ver promoción en el portal <ExternalLink size={12} />
              </Link>
            </div>
          </Tarjeta>
        </div>

        <div>
          <h2 className="mb-3 font-display uppercase tracking-wide text-tinta-900">Código QR — pruébalo con tu celular</h2>
          <Tarjeta className="flex flex-col items-center gap-4 p-6">
            {qr ? <img src={qr} alt="Código QR hacia el portal" className="h-48 w-48" /> : <div className="h-48 w-48 animate-pulse rounded-xl bg-papel-200" />}
            <p className="break-all text-center text-xs text-tinta-400">{url}</p>
            <Button as="a" href={`#/promo/${promo.slug}`} variant="outline" size="sm">Abrir enlace</Button>
          </Tarjeta>

          <h2 className="mb-3 mt-6 font-display uppercase tracking-wide text-tinta-900">Perfil de Google</h2>
          <Tarjeta className="flex items-center gap-3 p-4">
            <div className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-verde-100 text-verde-700"><IconInstagram size={18} /></div>
            <div className="min-w-0 flex-1">
              <p className="font-bold text-tinta-800">{BUSINESS.name}</p>
              <p className="flex items-center gap-1 text-xs text-tinta-500">
                <Star size={12} className="fill-naranja-400 text-naranja-400" /> 4.7 · Tienda de abarrotes · {BUSINESS.town}
              </p>
            </div>
          </Tarjeta>
        </div>
      </div>

      <h2 className="mb-3 mt-8 font-display uppercase tracking-wide text-tinta-900">Recorrido completo del cliente</h2>
      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {PASOS.map((p, i) => (
          <Tarjeta key={i} className="flex gap-3 p-4">
            <span className="grid h-7 w-7 shrink-0 place-items-center rounded-full bg-verde-600 text-xs font-bold text-papel-50">{i + 1}</span>
            <p className="text-sm text-tinta-600">{p}</p>
          </Tarjeta>
        ))}
      </div>
    </Contenedor>
  )
}
