import { useState } from 'react'
import { CATEGORIAS, PRODUCTOS } from '../data/catalogo.js'
import { useDemo } from '../store/DemoStore.jsx'
import { Contenedor, PageHeader } from '../shell/Layout.jsx'
import { Tarjeta, Switch, Chip, Input } from '../ui/index.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'
import { money } from '../lib/format.js'

export default function NegocioCatalogo() {
  const { state, setPrice, setAvailability } = useDemo()
  const [cat, setCat] = useState('todas')

  const productos = PRODUCTOS.filter((p) => cat === 'todas' || p.categoria === cat)

  return (
    <Contenedor ancho="ancho">
      <PageHeader title="Catálogo" sub="Cambia un precio o apaga un agotado — se ve al instante en el portal del cliente." />

      <div className="no-scrollbar mb-4 flex gap-2 overflow-x-auto pb-1">
        <Chip active={cat === 'todas'} onClick={() => setCat('todas')}>Todo</Chip>
        {CATEGORIAS.map((c) => <Chip key={c.id} active={cat === c.id} onClick={() => setCat(c.id)}>{c.nombre}</Chip>)}
      </div>

      <Tarjeta className="overflow-hidden">
        <div className="hidden grid-cols-[1fr_120px_120px_100px] gap-3 border-b border-papel-200 px-4 py-3 text-xs font-bold uppercase tracking-wide text-tinta-400 sm:grid">
          <span>Producto</span>
          <span>Precio</span>
          <span>Precio de fábrica</span>
          <span>Disponible</span>
        </div>
        <div className="divide-y divide-papel-100">
          {productos.map((p) => (
            <div key={p.id} className="grid grid-cols-2 items-center gap-3 px-4 py-3 sm:grid-cols-[1fr_120px_120px_100px]">
              <div className="col-span-2 flex min-w-0 items-center gap-3 sm:col-span-1">
                <FoodArt fotoId={p.fotoId} size="thumb" className="h-11 w-11 shrink-0 rounded-lg" />
                <div className="min-w-0">
                  <p className="truncate text-sm font-semibold text-tinta-800">{p.nombre}</p>
                  <p className="text-xs text-tinta-400">por {p.unidad === 'und' ? 'unidad' : p.unidad}</p>
                </div>
              </div>
              <Input
                type="number"
                step="0.01"
                value={state.prices[p.id] ?? p.precio}
                onChange={(e) => setPrice(p.id, parseFloat(e.target.value) || 0)}
                className="h-9 w-24"
              />
              <span className="text-sm text-tinta-400">{money(p.precio)}</span>
              <Switch checked={state.availability[p.id] !== false} onChange={(v) => setAvailability(p.id, v)} />
            </div>
          ))}
        </div>
      </Tarjeta>
    </Contenedor>
  )
}
