import { Link } from 'react-router-dom'
import { ClipboardList, PackageCheck, CheckCircle2, DollarSign, ArrowRight } from 'lucide-react'
import { useDemo, useNow } from '../store/DemoStore.jsx'
import { productoPorId, PRODUCTOS } from '../data/catalogo.js'
import { lineTotal } from '../store/pricing.js'
import { Contenedor, PageHeader, SectionHeader } from '../shell/Layout.jsx'
import { Tarjeta, Button } from '../ui/index.jsx'
import { money } from '../lib/format.js'

function esHoy(ts) {
  const d = new Date(ts), n = new Date()
  return d.toDateString() === n.toDateString()
}

export default function NegocioResumen() {
  const { state } = useDemo()
  useNow(20000)

  const pedidosHoy = state.orders.filter((o) => esHoy(o.createdAt) && o.status !== 'cancelado')
  const empacando = state.orders.filter((o) => ['preparando', 'empacado'].includes(o.status))
  const listos = state.orders.filter((o) => ['listo', 'en_camino'].includes(o.status))
  const ventasHoy = pedidosHoy.reduce((sum, o) => sum + o.items.reduce((s, it) => s + lineTotal(it, state.prices), 0), 0)
  const porConfirmar = state.orders.filter((o) => o.status === 'recibido')

  const porHora = Array.from({ length: 8 }, (_, i) => {
    const hora = 7 + i
    const count = pedidosHoy.filter((o) => new Date(o.createdAt).getHours() === hora).length + Math.floor(Math.random() * 3)
    return { hora, count }
  })
  const maxHora = Math.max(1, ...porHora.map((h) => h.count))

  const canalTotales = { instagram: 44, whatsapp: 31, mostrador: 25 }
  const totalCanal = Object.values(canalTotales).reduce((a, b) => a + b, 0)

  const ventasPorProducto = {}
  state.orders.forEach((o) => o.items.forEach((it) => {
    ventasPorProducto[it.productId] = (ventasPorProducto[it.productId] || 0) + lineTotal(it, state.prices)
  }))
  const topProductos = Object.entries(ventasPorProducto).sort((a, b) => b[1] - a[1]).slice(0, 5)

  return (
    <Contenedor>
      <PageHeader title="Resumen del negocio" sub="Así ve el dueño lo que está pasando ahora mismo." />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        <KPI icon={ClipboardList} label="Pedidos de hoy" value={pedidosHoy.length} tone="primario" />
        <KPI icon={PackageCheck} label="Empacando" value={empacando.length} tone="acento" />
        <KPI icon={CheckCircle2} label="Listos" value={listos.length} tone="exito" />
        <KPI icon={DollarSign} label="Ventas de hoy" value={money(ventasHoy)} tone="tinta" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1.6fr_1fr]">
        <Tarjeta className="p-5">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="font-display uppercase tracking-wide text-tinta-900">Solicitudes por confirmar</h2>
            {porConfirmar.length > 0 && <Button as={Link} to="/negocio/empaque" size="sm" variant="naranja">Ir a Empaque</Button>}
          </div>
          {porConfirmar.length === 0 ? (
            <p className="py-6 text-center text-sm text-tinta-400">No hay pedidos nuevos por confirmar.</p>
          ) : (
            <div className="space-y-2">
              {porConfirmar.slice(0, 4).map((o) => (
                <div key={o.id} className="flex items-center justify-between rounded-xl bg-papel-100 px-3 py-2 text-sm">
                  <span className="font-semibold text-tinta-700">{o.code} · {o.customerName}</span>
                  <span className="text-tinta-400">{o.items.length} productos</span>
                </div>
              ))}
            </div>
          )}

          <h2 className="mb-3 mt-6 font-display uppercase tracking-wide text-tinta-900">Pedidos por hora</h2>
          <div className="flex h-32 items-end gap-2">
            {porHora.map((h) => (
              <div key={h.hora} className="flex flex-1 flex-col items-center gap-1">
                <div className="w-full rounded-t-lg bg-verde-500" style={{ height: `${(h.count / maxHora) * 100}%`, minHeight: 4 }} />
                <span className="text-[10px] text-tinta-400">{h.hora}</span>
              </div>
            ))}
          </div>
        </Tarjeta>

        <Tarjeta className="p-5">
          <h2 className="mb-4 font-display uppercase tracking-wide text-tinta-900">Canales</h2>
          <div className="flex items-center justify-center">
            <div
              className="grid h-32 w-32 place-items-center rounded-full"
              style={{
                background: `conic-gradient(var(--color-verde-600) 0 ${(canalTotales.instagram / totalCanal) * 360}deg, var(--color-naranja-400) 0 ${((canalTotales.instagram + canalTotales.whatsapp) / totalCanal) * 360}deg, var(--color-tinta-300) 0 360deg)`,
              }}
            >
              <div className="grid h-20 w-20 place-items-center rounded-full bg-white text-center">
                <span className="font-display text-lg text-tinta-900">{totalCanal}</span>
              </div>
            </div>
          </div>
          <div className="mt-4 space-y-2 text-sm">
            <Leyenda color="bg-verde-600" label="Instagram" value={`${canalTotales.instagram}%`} />
            <Leyenda color="bg-naranja-400" label="WhatsApp" value={`${canalTotales.whatsapp}%`} />
            <Leyenda color="bg-tinta-300" label="Mostrador" value={`${canalTotales.mostrador}%`} />
          </div>
        </Tarjeta>
      </div>

      <SectionHeader title="Top productos" />
      <div className="grid gap-2 sm:grid-cols-2 lg:grid-cols-5">
        {topProductos.map(([id, total]) => {
          const p = productoPorId(id)
          if (!p) return null
          return (
            <Tarjeta key={id} className="p-3">
              <p className="truncate text-sm font-semibold text-tinta-800">{p.nombre}</p>
              <p className="text-sm font-bold text-verde-700">{money(total)}</p>
            </Tarjeta>
          )
        })}
      </div>

      <SectionHeader title="Cómo fluye un pedido internamente" />
      <div className="grid grid-cols-1 gap-2 sm:grid-cols-5">
        {['Recibido en el portal', 'Se separa en tienda', 'Se empaca', 'Se marca listo', 'Se entrega o recoge'].map((t, i) => (
          <div key={i} className="flex items-center gap-2">
            <Tarjeta className="flex-1 p-3 text-center text-xs font-semibold text-tinta-600">{t}</Tarjeta>
            {i < 4 && <ArrowRight size={14} className="hidden shrink-0 text-tinta-300 sm:block" />}
          </div>
        ))}
      </div>
    </Contenedor>
  )
}

function KPI({ icon: Icon, label, value, tone }) {
  const tones = { primario: 'bg-verde-100 text-verde-700', acento: 'bg-naranja-100 text-naranja-600', exito: 'bg-oliva-100 text-oliva-700', tinta: 'bg-tinta-800 text-papel-100' }
  return (
    <Tarjeta className="p-4">
      <div className={`mb-2 inline-grid h-9 w-9 place-items-center rounded-full ${tones[tone]}`}>
        <Icon size={17} />
      </div>
      <p className="font-display text-2xl text-tinta-900">{value}</p>
      <p className="text-xs text-tinta-400">{label}</p>
    </Tarjeta>
  )
}

function Leyenda({ color, label, value }) {
  return (
    <div className="flex items-center justify-between">
      <span className="flex items-center gap-2 text-tinta-600"><span className={`h-2.5 w-2.5 rounded-full ${color}`} /> {label}</span>
      <span className="font-semibold text-tinta-800">{value}</span>
    </div>
  )
}
