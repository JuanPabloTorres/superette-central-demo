import { useEffect, useState } from 'react'
import { Search, ArrowRight, X, Printer, Truck, Store } from 'lucide-react'
import { useDemo, useNow, BOARD_COLUMNS } from '../store/DemoStore.jsx'
import { describeItem, lineTotal } from '../store/pricing.js'
import { productoPorId, PRODUCTOS } from '../data/catalogo.js'
import { Contenedor, PageHeader } from '../shell/Layout.jsx'
import { Tarjeta, Button, Modal, SheetHeader, Switch, EmptyState, Badge, cx } from '../ui/index.jsx'
import { money } from '../lib/format.js'

export default function NegocioEmpaque() {
  const { state, setStatus, cancelOrder, markSeen, setAvailability, toast } = useDemo()
  const [agotadosOpen, setAgotadosOpen] = useState(false)
  const [q, setQ] = useState('')
  useNow(1000)

  const activos = state.orders.filter((o) => o.status !== 'entregado' && o.status !== 'cancelado')

  const columnas = BOARD_COLUMNS.map((col) => ({
    ...col,
    ordenes: activos.filter((o) => col.estados.includes(o.status)).sort((a, b) => a.createdAt - b.createdAt),
  }))

  useEffect(() => {
    const nuevas = columnas[0]?.ordenes.filter((o) => !state.kdsSeen.includes(o.id)) || []
    if (nuevas.length) {
      const t = setTimeout(() => nuevas.forEach((o) => markSeen(o.id)), 6000)
      return () => clearTimeout(t)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [columnas[0]?.ordenes.length])

  const productosFiltrados = PRODUCTOS.filter((p) => p.nombre.toLowerCase().includes(q.toLowerCase()))

  return (
    <Contenedor ancho="ancho">
      <PageHeader
        title="Empaque"
        sub="Un toque para avanzar cada pedido."
        right={<Button variant="papel" onClick={() => setAgotadosOpen(true)}>Agotados</Button>}
      />

      <div className="grid gap-4 md:grid-cols-3">
        {columnas.map((col) => (
          <div key={col.key}>
            <div className="mb-3 flex items-center gap-2">
              <span className={cx('h-2.5 w-2.5 rounded-full', col.key === 'recibido' ? 'bg-naranja-500' : col.key === 'empacando' ? 'bg-verde-500' : 'bg-oliva-600')} />
              <h3 className="font-display uppercase tracking-wide text-tinta-900">{col.label}</h3>
              <Badge tone="neutral">{col.ordenes.length}</Badge>
            </div>
            <div className="space-y-3">
              {col.ordenes.length === 0 && <EmptyState title="Nada aquí por ahora." />}
              {col.ordenes.map((o) => (
                <TarjetaOrden
                  key={o.id}
                  orden={o}
                  esNueva={col.key === 'recibido' && !state.kdsSeen.includes(o.id)}
                  onAvanzar={() => { setStatus(o.id); toast(`${o.code} avanzó de estado`) }}
                  onCancelar={() => cancelOrder(o.id)}
                  prices={state.prices}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      <Modal open={agotadosOpen} onClose={() => setAgotadosOpen(false)} size="lg">
        <SheetHeader title="Control de agotados" subtitle="Apaga un producto y desaparece del catálogo del cliente al instante." onClose={() => setAgotadosOpen(false)} />
        <div className="space-y-3 px-5 py-5">
          <div className="flex items-center gap-2 rounded-xl border border-papel-300 px-3 py-2">
            <Search size={16} className="text-tinta-400" />
            <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar producto…" className="w-full bg-transparent text-sm outline-none" />
          </div>
          <div className="max-h-96 space-y-1 overflow-y-auto">
            {productosFiltrados.map((p) => (
              <div key={p.id} className="flex items-center justify-between rounded-xl px-2 py-2 hover:bg-papel-100">
                <span className="text-sm text-tinta-700">{p.nombre}</span>
                <Switch checked={state.availability[p.id] !== false} onChange={(v) => setAvailability(p.id, v)} />
              </div>
            ))}
          </div>
        </div>
      </Modal>
    </Contenedor>
  )
}

function TarjetaOrden({ orden, esNueva, onAvanzar, onCancelar, prices }) {
  const now = useNow(1000)
  const secs = Math.floor((now - orden.statusHistory[orden.statusHistory.length - 1].at) / 1000)
  const tarde = secs > 8 * 60
  const media = secs > 4 * 60
  const total = orden.items.reduce((s, it) => s + lineTotal(it, prices), 0)

  return (
    <Tarjeta className={cx('space-y-2 p-4', esNueva && 'ring-2 ring-naranja-300 animate-pop')}>
      <div className="flex items-center justify-between">
        <span className="flex items-center gap-1.5 font-bold text-tinta-800">
          {orden.mode === 'delivery' ? <Truck size={14} className="text-verde-600" /> : <Store size={14} className="text-verde-600" />}
          {orden.code}
        </span>
        <span className={cx('rounded-full px-2 py-0.5 text-xs font-bold', tarde ? 'bg-red-100 text-red-600' : media ? 'bg-naranja-100 text-naranja-600' : 'bg-papel-200 text-tinta-500')}>
          {Math.floor(secs / 60)}:{String(secs % 60).padStart(2, '0')}
        </span>
      </div>
      <p className="text-xs text-tinta-400">{orden.customerName}</p>
      <div className="space-y-1">
        {orden.items.slice(0, 3).map((it, i) => {
          const p = productoPorId(it.productId)
          return <p key={i} className="truncate text-xs text-tinta-600">{p.nombre} — {describeItem(it).join(', ')}</p>
        })}
        {orden.items.length > 3 && <p className="text-xs text-tinta-400">+{orden.items.length - 3} más</p>}
      </div>
      <p className="text-sm font-bold text-verde-700">{money(total)}</p>
      <div className="flex gap-2 pt-1">
        <Button variant="primary" size="sm" className="flex-1" onClick={onAvanzar}><ArrowRight size={14} /> Avanzar</Button>
        <button aria-label="Imprimir" className="grid h-9 w-9 place-items-center rounded-full border border-papel-300 text-tinta-500 hover:border-verde-400">
          <Printer size={14} />
        </button>
        <button aria-label="Cancelar" onClick={onCancelar} className="grid h-9 w-9 place-items-center rounded-full border border-papel-300 text-tinta-500 hover:border-red-400 hover:text-red-500">
          <X size={14} />
        </button>
      </div>
    </Tarjeta>
  )
}
