import { Link2, Star, Tag } from 'lucide-react'
import { PROMOS } from '../data/promos.js'
import { useDemo } from '../store/DemoStore.jsx'
import { Contenedor, PageHeader } from '../shell/Layout.jsx'
import { Tarjeta, Switch, Button, Badge } from '../ui/index.jsx'
import { FoodArt } from '../ui/FoodArt.jsx'

function efectiva(promo, overrides) {
  const o = overrides[promo.id] || {}
  return { ...promo, activa: o.activa ?? promo.activa, destacada: o.destacada ?? promo.destacada }
}

export default function NegocioPromociones() {
  const { state, togglePromo, featurePromo, toast } = useDemo()
  const promos = PROMOS.map((p) => efectiva(p, state.promoOverrides))

  const copiarEnlace = (promo) => {
    const url = `${window.location.origin}${window.location.pathname}#/promo/${promo.slug}`
    navigator.clipboard?.writeText(url).catch(() => {})
    toast('Enlace copiado — listo para pegar en Instagram', 'success')
  }

  return (
    <Contenedor>
      <PageHeader title="Promociones" sub="Activa, pausa o destaca una oferta. Copia el enlace directo para tus redes." />

      <div className="space-y-3">
        {promos.map((p) => (
          <Tarjeta key={p.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center">
            <FoodArt fotoId={p.fotoId} size="thumb" className="h-16 w-16 shrink-0 rounded-xl" />
            <div className="min-w-0 flex-1">
              <div className="flex flex-wrap items-center gap-2">
                <p className="font-bold text-tinta-800">{p.titulo}</p>
                {p.destacada && <Badge tone="amber">Destacada</Badge>}
                <Badge tone={p.activa ? 'green' : 'neutral'}>{p.activa ? 'Activa' : 'Pausada'}</Badge>
              </div>
              <p className="text-sm text-tinta-500">{p.resumen}</p>
            </div>
            <div className="flex shrink-0 items-center gap-2">
              <Switch checked={p.activa} onChange={() => togglePromo(p.id)} />
              <Button variant={p.destacada ? 'naranja' : 'papel'} size="sm" onClick={() => featurePromo(p.id)}>
                <Star size={14} /> Destacar
              </Button>
              <Button variant="soft" size="sm" onClick={() => copiarEnlace(p)}>
                <Link2 size={14} />
              </Button>
            </div>
          </Tarjeta>
        ))}
      </div>

      {promos.length === 0 && (
        <div className="flex flex-col items-center gap-2 py-10 text-tinta-400">
          <Tag size={24} /> No hay promociones configuradas.
        </div>
      )}
    </Contenedor>
  )
}
