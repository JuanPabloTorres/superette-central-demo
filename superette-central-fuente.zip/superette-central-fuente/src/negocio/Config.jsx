import { RefreshCcw } from 'lucide-react'
import { useDemo } from '../store/DemoStore.jsx'
import { BUSINESS } from '../data/config.js'
import { Contenedor, PageHeader, SectionHeader } from '../shell/Layout.jsx'
import { Tarjeta, Field, Input, Switch, Button } from '../ui/index.jsx'

export default function NegocioConfig() {
  const { state, setSettings, reset } = useDemo()
  const s = state.settings

  return (
    <Contenedor ancho="angosto">
      <PageHeader title="Configuración" sub="Los mismos números que controlan lo que ve el cliente." />

      <Tarjeta className="space-y-4 p-5">
        <Switch checked={s.acceptingOrders} onChange={(v) => setSettings({ acceptingOrders: v })} label="Aceptando pedidos ahora" />
        <Switch checked={s.busyMode} onChange={(v) => setSettings({ busyMode: v })} label="Modo ocupado (tiempos más largos)" />
        <div className="grid gap-3 sm:grid-cols-2">
          <Switch checked={s.modes.pickup} onChange={(v) => setSettings({ modes: { ...s.modes, pickup: v } })} label="Recoger en tienda activo" />
          <Switch checked={s.modes.delivery} onChange={(v) => setSettings({ modes: { ...s.modes, delivery: v } })} label="Entrega a domicilio activa" />
        </div>
      </Tarjeta>

      <SectionHeader title="Tiempos y cargos" />
      <Tarjeta className="grid gap-4 p-5 sm:grid-cols-2">
        <Field label="Minutos de preparación"><Input type="number" value={s.prepMinutes} onChange={(e) => setSettings({ prepMinutes: +e.target.value })} /></Field>
        <Field label="Minutos de entrega"><Input type="number" value={s.deliveryMinutes} onChange={(e) => setSettings({ deliveryMinutes: +e.target.value })} /></Field>
        <Field label="Cargo de entrega ($)"><Input type="number" step="0.01" value={s.deliveryFee} onChange={(e) => setSettings({ deliveryFee: +e.target.value })} /></Field>
        <Field label="Mínimo para entrega ($)"><Input type="number" step="0.01" value={s.deliveryMinimum} onChange={(e) => setSettings({ deliveryMinimum: +e.target.value })} /></Field>
        <Field label="Tasa de impuesto (IVU)" hint="0.115 = 11.5%"><Input type="number" step="0.001" value={s.taxRate} onChange={(e) => setSettings({ taxRate: +e.target.value })} /></Field>
      </Tarjeta>

      <SectionHeader title="Recompensas" />
      <Tarjeta className="grid gap-4 p-5 sm:grid-cols-3">
        <Field label="Puntos por dólar"><Input type="number" value={s.pointsPerDollar} onChange={(e) => setSettings({ pointsPerDollar: +e.target.value })} /></Field>
        <Field label="Meta de puntos"><Input type="number" value={s.rewardGoalPoints} onChange={(e) => setSettings({ rewardGoalPoints: +e.target.value })} /></Field>
        <Field label="Valor de la recompensa ($)"><Input type="number" step="0.01" value={s.rewardValue} onChange={(e) => setSettings({ rewardValue: +e.target.value })} /></Field>
      </Tarjeta>

      <SectionHeader title="Horario" />
      <Tarjeta className="divide-y divide-papel-100 p-2">
        {BUSINESS.hours.map((h) => (
          <div key={h.day} className="flex items-center justify-between px-3 py-2 text-sm">
            <span className="font-semibold text-tinta-700">{h.day}</span>
            <span className="text-tinta-500">{h.open} – {h.close}</span>
          </div>
        ))}
      </Tarjeta>

      <SectionHeader title="Reiniciar" />
      <Tarjeta className="flex items-center justify-between p-5">
        <p className="text-sm text-tinta-500">Vuelve el demo a su estado inicial, con los pedidos y clientes sembrados.</p>
        <Button variant="danger" onClick={reset}><RefreshCcw size={15} /> Reiniciar</Button>
      </Tarjeta>
    </Contenedor>
  )
}
