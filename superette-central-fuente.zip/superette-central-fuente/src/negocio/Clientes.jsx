import { useState } from 'react'
import { Search, Users } from 'lucide-react'
import { useDemo } from '../store/DemoStore.jsx'
import { Contenedor, PageHeader } from '../shell/Layout.jsx'
import { Tarjeta, Badge, EmptyState } from '../ui/index.jsx'
import { money } from '../lib/format.js'

export default function NegocioClientes() {
  const { state } = useDemo()
  const [q, setQ] = useState('')

  const clientes = [...state.customers]
    .filter((c) => c.nombre.toLowerCase().includes(q.toLowerCase()))
    .sort((a, b) => b.totalGastado - a.totalGastado)

  return (
    <Contenedor>
      <PageHeader title="Clientes" sub="Quiénes compran más seguido y cuántos puntos tienen acumulados." />

      <div className="mb-4 flex items-center gap-2 rounded-2xl border border-papel-300 bg-white px-4 py-3">
        <Search size={18} className="text-tinta-400" />
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Buscar cliente…" className="w-full bg-transparent text-sm outline-none placeholder:text-tinta-300" />
      </div>

      {clientes.length === 0 ? (
        <EmptyState icon={Users} title="No hay clientes con ese nombre." />
      ) : (
        <Tarjeta className="overflow-hidden">
          <div className="hidden grid-cols-[1fr_140px_100px_120px] gap-3 border-b border-papel-200 px-4 py-3 text-xs font-bold uppercase tracking-wide text-tinta-400 sm:grid">
            <span>Cliente</span>
            <span>Teléfono</span>
            <span>Puntos</span>
            <span>Total gastado</span>
          </div>
          <div className="divide-y divide-papel-100">
            {clientes.map((c) => (
              <div key={c.id} className="grid grid-cols-2 items-center gap-2 px-4 py-3 text-sm sm:grid-cols-[1fr_140px_100px_120px]">
                <span className="font-semibold text-tinta-800">{c.nombre}</span>
                <span className="text-tinta-500">{c.telefono}</span>
                <span><Badge tone="amber">{c.puntos} pts</Badge></span>
                <span className="font-bold text-verde-700">{money(c.totalGastado)}</span>
              </div>
            ))}
          </div>
        </Tarjeta>
      )}
    </Contenedor>
  )
}
