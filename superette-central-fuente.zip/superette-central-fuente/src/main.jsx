import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { HashRouter } from 'react-router-dom'
import './index.css'
import { DemoProvider } from './store/DemoStore.jsx'
import { Shell } from './shell/Shell.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <HashRouter>
      <DemoProvider>
        <Shell />
      </DemoProvider>
    </HashRouter>
  </StrictMode>,
)
