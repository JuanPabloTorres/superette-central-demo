import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'
import { viteSingleFile } from 'vite-plugin-singlefile'
import { readFileSync, writeFileSync } from 'node:fs'
import { fileURLToPath } from 'node:url'
import { dirname, resolve } from 'node:path'

const __dirname = dirname(fileURLToPath(import.meta.url))

// vite-plugin-singlefile + format:'iife' produces a plain script with no
// import/export syntax, but Vite's HTML transform still emits it as
// type="module" and places it in <head>. That combination breaks in two
// independent ways for a double-clicked / sandboxed-preview file: (1) the
// type="module" tag alone makes some viewers (Firefox over file://,
// sandboxed iframes without allow-same-origin) refuse to run it at all, and
// (2) dropping the module type also drops its implicit defer behavior, so a
// plain inline <script> in <head> would then execute before #root exists in
// the DOM. Since the bundled code has no ESM syntax left, it's safe to pull
// it out of <head> and re-insert it as a classic script right before
// </body>, after the DOM it needs already exists.
function stripModuleType() {
  return {
    name: 'strip-module-type',
    apply: 'build',
    closeBundle() {
      const file = resolve(__dirname, 'dist/index.html')
      const html = readFileSync(file, 'utf-8')
      const openTag = '<script type="module" crossorigin>'
      const start = html.indexOf(openTag)
      if (start === -1) return
      const closeTag = '</script>'
      const end = html.indexOf(closeTag, start) + closeTag.length
      const scriptContent = html.slice(start + openTag.length, end - closeTag.length)
      const withoutScript = html.slice(0, start) + html.slice(end)
      const bodyCloseIdx = withoutScript.indexOf('</body>')
      const finalHtml =
        withoutScript.slice(0, bodyCloseIdx) +
        `<script>${scriptContent}</script>\n  ` +
        withoutScript.slice(bodyCloseIdx)
      writeFileSync(file, finalHtml)
    },
  }
}

export default defineConfig({
  base: './',
  plugins: [react(), tailwindcss(), viteSingleFile(), stripModuleType()],
  build: {
    cssCodeSplit: false,
    assetsInlineLimit: 100000000,
    chunkSizeWarningLimit: 5000,
    target: 'es2015',
    modulePreload: false,
    rollupOptions: {
      output: {
        format: 'iife',
        inlineDynamicImports: true,
      },
    },
  },
})
