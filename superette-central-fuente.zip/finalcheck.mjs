import { chromium } from 'playwright'
const B = 'http://127.0.0.1:4177/'
const RUTAS = [
  '#/', '#/catalogo', '#/promociones', '#/promo/viernes-de-pechuga', '#/carrito',
  '#/mis-ordenes', '#/alertas', '#/cuenta', '#/eventos',
  '#/negocio', '#/negocio/empaque', '#/negocio/catalogo', '#/negocio/promociones',
  '#/negocio/clientes', '#/negocio/canales', '#/negocio/config',
]
const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })
let bad = []
for (const w of [360, 390, 414, 1280]) {
  const page = await browser.newPage({ viewport: { width: w, height: 800 } })
  page.on('pageerror', (err) => bad.push(`[${w}px ${page.url()}] PAGEERROR: ${err.message}`))
  for (const r of RUTAS) {
    await page.goto(B + r)
    await page.waitForTimeout(450)
    const info = await page.evaluate(() => ({ vw: document.documentElement.clientWidth, sw: document.documentElement.scrollWidth }))
    if (info.vw !== info.sw) bad.push(`${w}px ${r} DESBORDA ${info.sw} vs ${info.vw}`)
  }
  await page.close()
}
await browser.close()
console.log(bad.length ? bad.join('\n') : 'RUTAS: OK — sin overflow, sin errores.')

// file:// check
const b2 = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium-1194/chrome-linux/chrome' })
const p2 = await b2.newPage()
const fileErrors = []
p2.on('pageerror', (e) => fileErrors.push(e.message))
await p2.goto('file:///home/claude/superette-demo/dist/index.html')
await p2.waitForTimeout(1200)
const rootLen = await p2.evaluate(() => document.getElementById('root')?.innerHTML?.length || 0)
console.log('FILE://  root innerHTML length:', rootLen, '| errores:', fileErrors.length ? fileErrors.join(', ') : 'ninguno')
await b2.close()
